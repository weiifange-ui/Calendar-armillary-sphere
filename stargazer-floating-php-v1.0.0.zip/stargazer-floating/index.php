<?php
/* 觀星渾天儀・懸空版：頁面入口
   外觀與 3D 動畫在 assets/，資料與規則在 api/ 與 data/ */
require __DIR__ . '/includes/config.php';
$ver  = htmlspecialchars(APP_VERSION);
$name = htmlspecialchars(APP_NAME);
?>
<!doctype html>
<html lang="zh-Hant">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= $name ?> v<?= $ver ?></title>
<script src="https://cdn.jsdelivr.net/npm/lunar-javascript@1.7.7/lunar.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.147.0/build/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.147.0/examples/js/controls/OrbitControls.js"></script>
<link rel="stylesheet" href="assets/style.css?v=<?= $ver ?>">
</head>
<body>
<canvas id="bgSky" aria-hidden="true"></canvas>
<header class="masthead">
  <h1>觀星渾天儀・懸空版</h1>
  <p>真實行星運行 × 今晚觀星條件 × 天象預報 <span class="ver-badge">v<?= $ver ?></span></p>
</header>
<main class="layout">
  <section class="stage-wrap" aria-label="太陽系天文儀">
    <div class="stage" id="stage">
      <canvas id="dust" aria-hidden="true"></canvas>
      <div id="gl" role="img" aria-label="以太陽為中心的 3D 黃銅天文儀，行星依真實軌道運行，光線指向它們在星座中的位置"></div>
      <p class="loading" id="loading">正在組裝天文儀…</p>
      <div class="readout-box" id="readout"><span id="orrLabel">儀器指示</span><b id="orrDate"></b></div>
      <p class="hint" id="hint">從地球射出的光線，落在外圈哪個星座，就是今晚在天空中看到該行星的位置。拖曳地球或刻度環可轉動日期，拖曳空白處可旋轉視角。</p>
      <div class="plaque" id="plaque" hidden role="dialog" aria-live="polite"></div>
    </div>
    <div class="stage-controls">
      <button class="btn" id="playBtn" aria-pressed="false">▶ 推進時光</button>
      <select class="sel-ui" id="speedSel" aria-label="推進速度">
        <option value="0.0416667">每秒 1 小時</option>
        <option value="1">每秒 1 天</option>
        <option value="7" selected>每秒 7 天</option>
        <option value="30">每秒 30 天</option>
      </select>
      <button class="btn" id="viewBtn">回到正面視角</button>
      <select class="sel-ui" id="qualitySel" aria-label="畫質">
        <option value="high">畫質：高</option>
        <option value="mid">畫質：中</option>
        <option value="low">畫質：低</option>
      </select>
    </div>
  </section>

  <aside class="panel" id="panel">
    <section class="card" aria-live="polite">
      <div class="when">
        <p class="md" id="wMD"></p><p class="tm" id="wTime"></p>
        <p class="yw" id="wYW"></p>
      </div>
      <div class="locrow">
        <label for="locSel">觀測地點</label>
        <select class="sel-ui" id="locSel"></select>
        <span id="customLoc" hidden>緯度 <input id="latIn" type="number" step="0.01" min="-89" max="89"> 經度 <input id="lonIn" type="number" step="0.01" min="-180" max="180"></span>
      </div>
      <div class="quick">
        <button class="btn" data-open="dr-night">🔭 今晚觀星</button>
        <button class="btn" data-open="dr-day">📝 行程與紀念日</button>
        <button class="btn" data-open="dr-wx">⛅ 天氣</button>
      </div>
    </section>

    <section class="card">
      <div class="nav-row">
        <button class="nav-btn" id="prevY" aria-label="上一年">«</button>
        <button class="nav-btn" id="prevM" aria-label="上個月">‹</button>
        <h3 id="monthTitle"></h3>
        <button class="nav-btn" id="nextM" aria-label="下個月">›</button>
        <button class="nav-btn" id="nextY" aria-label="下一年">»</button>
      </div>
      <div class="grid" id="grid" role="grid" aria-label="觀星日曆"></div>
      <p class="legend"><span>色條長度為無月暗夜時數：</span><span><i style="background:var(--g4)"></i>極佳</span><span><i style="background:var(--g3)"></i>良好</span><span><i style="background:var(--g2)"></i>普通</span><span><i style="background:var(--g1)"></i>不佳</span></p>
      <div class="tools">
        <label>前往日期 <input type="date" id="dateInput" min="1901-01-01" max="2099-12-31"></label>
        <button class="btn" id="nowBtn">回到現在</button>
      </div>
      <p class="msg" id="msg"></p>
    </section>

  </aside>
</main>
<button class="drawer-tab" id="drawerTab" aria-controls="drawer" aria-expanded="false" aria-label="更多功能">☰<span class="v" aria-hidden="true">更<br>多<br>功<br>能</span><span class="h" aria-hidden="true">更多功能</span></button>
<div class="drawer-mask" id="drawerMask"></div>
<aside class="drawer" id="drawer" aria-label="功能抽屜" aria-hidden="true">
  <div class="drawer-head"><h2>功能</h2><button class="close" id="drawerClose" aria-label="關閉抽屜">✕</button></div>
  <nav class="drawer-nav" aria-label="功能目錄"><button data-go="dr-night">觀星條件</button><button data-go="dr-sky">夜空圖</button><button data-go="dr-planets">行星</button><button data-go="dr-events">天象預報</button><button data-go="dr-day">行程與紀念日</button><button data-go="dr-up">即將到來</button><button data-go="dr-wx">鄉鎮天氣</button><button data-go="dr-learn">每日學習</button></nav>
  <div class="drawer-body panel">

    <section class="card" id="dr-night">
      <h2>今晚觀星條件 <span class="grade" id="gradeChip"></span><span class="aside" id="nightLabel"></span></h2>
      <dl class="rows" id="nightRows"></dl>
    </section>

    <section class="card" id="dr-sky">
      <h2>夜空圖 <span class="aside">頭頂為圓心，邊緣為地平線</span></h2>
      <div class="sky-wrap">
        <svg id="skyChart" viewBox="-170 -170 340 362" role="img" aria-label="夜空圖"></svg>
        <div class="slider-row"><span>17:00</span><input type="range" id="timeSlider" min="0" max="840" step="5" aria-label="今晚時刻"><span>07:00</span><b id="sliderTime"></b></div>
      </div>
    </section>

    <section class="card" id="dr-planets">
      <h2>今晚的行星</h2>
      <table class="ptable"><thead><tr><th>行星</th><th>所在星座</th><th>亮度</th><th>可見時段與方位</th></tr></thead><tbody id="pBody"></tbody></table>
    </section>

    <section class="card" id="dr-events">
      <h2>天象預報 <span class="aside">未來 60 天</span></h2>
      <ul class="events" id="evList"></ul>
    </section>
  <section class="card" id="dr-day" aria-labelledby="dayTitle">
    <h2 class="sh"><span id="dayTitle">這一天</span></h2>
    <ul class="items" id="dayItems"></ul>
    <form class="addrow" id="evForm">
      <input id="evTime" type="time" aria-label="時間（可不填）">
      <input id="evTitle" required maxlength="60" placeholder="新增行程，例如：看牙醫" aria-label="行程內容">
      <button class="btn small" type="submit">新增行程</button>
    </form>
    <form class="addrow" id="anForm">
      <input id="anName" required maxlength="40" placeholder="紀念日名稱，例如：結婚紀念日" aria-label="紀念日名稱">
      <select id="anType" aria-label="紀念日依據"><option value="solar">每年國曆同一天</option><option value="lunar">每年農曆同一天</option></select>
      <button class="btn small" type="submit">設為紀念日</button>
    </form>
    <p class="note" id="storeNote"></p>
  </section>
  <section class="card" id="dr-up">
    <h2 class="sh">即將到來 <span class="aside">從今天起 60 天</span></h2>
    <ul class="items up-list" id="upList"></ul>
  </section>
  <section class="card" id="dr-wx">
    <h2 class="sh">鄉鎮天氣 <span class="aside" id="wxPlace"></span></h2>
    <div class="wx-search">
      <input id="wxQ" placeholder="輸入鄉鎮區，例如：礁溪、玉里" aria-label="搜尋鄉鎮區">
      <button class="btn small" id="wxGo" type="button">搜尋</button>
      <select id="wxCounty" aria-label="選擇縣市"></select>
      <button class="btn small" id="wxHere" type="button">目前位置</button>
    </div>
    <ul class="wx-results" id="wxResults"></ul>
    <div id="wxBox"></div>
    <p class="note">天氣資料來自 Open-Meteo 開放氣象資料。</p>
  </section>
  <section class="card" id="dr-learn">
    <h2 class="sh">每日學習</h2>
    <div class="tabs" role="tablist">
      <button role="tab" aria-selected="true" data-tab="en">英文單字</button>
      <button role="tab" aria-selected="false" data-tab="code">程式碼</button>
    </div>
    <div id="learnBox" class="learn" aria-live="polite"></div>
    <div class="learn-nav">
      <button class="btn small" id="lPrev" type="button">‹ 前一則</button>
      <button class="btn small" id="lDone" type="button" aria-pressed="false">標記為已學會</button>
      <button class="btn small" id="lNext" type="button">下一則 ›</button>
    </div>
    <p class="note" id="learnStat"></p>
  </section>
  </div>
</aside>

<footer class="foot">
  <p>行程、紀念日與學習進度儲存在伺服器的 storage/planner.json；天氣由伺服器代為查詢並快取 30 分鐘。天氣資料來自 Open-Meteo，國定假日、補假、補班與連假：2017 至 2027 年採用行政院人事行政總處公布的「政府行政機關辦公日曆表」（政府資料開放平臺），其他年份尚無官方公告，依現行法規推算並標示「推算」。</p>
  <p>行星位置依 JPL 克卜勒軌道根數計算，月球依 Meeus 天文演算法，與專業星曆比對誤差多在數角分以內，升落時刻誤差約 1 分鐘。時間一律為台灣時間（UTC+8），未計入地形與海拔。天文儀上的軌道大小經過壓縮，方向與傾角則為真實數值。</p>
  <p>「無月暗夜」指太陽低於地平線 18° 且月亮未升起（或月相極細）的時段。日月食為近似計算，實際食分與時刻請以台北市立天文館公告為準。天氣與雲量請另查氣象預報；完整星圖可使用 <a href="https://stellarium-web.org/" target="_blank" rel="noopener">Stellarium Web</a>。</p>
  <p class="ver"><?= $name ?> v<?= $ver ?></p>
</footer>
<script>window.APP = { version: '<?= $ver ?>', api: 'api/' };</script>
<script src="assets/app.js?v=<?= $ver ?>"></script>
</body>
</html>
