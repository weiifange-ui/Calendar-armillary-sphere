<?php
/* ============================================================
   觀星渾天儀・懸空版：共用設定與工具函式
   每個 api/*.php 與 index.php 都會先載入這個檔案
   ============================================================ */

// 版本號：採用「語意化版本」主版號.次版號.修訂號
// 修正錯誤 → 修訂號 +1；新增功能 → 次版號 +1；大改版或不相容的變更 → 主版號 +1
const APP_VERSION = '1.0.0';
const APP_NAME    = '觀星渾天儀・懸空版';

// 資料夾位置（__DIR__ 是這個檔案所在的資料夾）
define('DATA_DIR', dirname(__DIR__) . '/data');
define('STORAGE_DIR', dirname(__DIR__) . '/storage');

date_default_timezone_set('Asia/Taipei');

/**
 * 輸出 JSON 並結束程式。
 * 每個回應都附上版本號，除錯時可以確認伺服器跑的是哪一版。
 */
function json_out(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-App-Version: ' . APP_VERSION);
    echo json_encode(['version' => APP_VERSION] + $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** 回傳錯誤訊息（ok = false） */
function json_error(string $message, int $status = 400): never
{
    json_out(['ok' => false, 'error' => $message], $status);
}

/** 讀取 POST 送來的 JSON 內容 */
function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);
    if (!is_array($data)) {
        json_error('送出的資料不是正確的 JSON');
    }
    return $data;
}

/** 讀取 JSON 檔；檔案不存在或格式錯誤時回傳預設值 */
function read_json_file(string $path, array $default = []): array
{
    if (!is_file($path)) {
        return $default;
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : $default;
}

/**
 * 以檔案鎖安全地「讀取 → 修改 → 寫回」JSON 檔。
 * 同時有兩個請求要寫入時，flock 會讓它們排隊，資料不會互相覆蓋。
 */
function update_json_file(string $path, array $default, callable $modify): array
{
    if (!is_dir(dirname($path))) {
        mkdir(dirname($path), 0775, true);
    }
    $fp = fopen($path, 'c+');
    if ($fp === false) {
        json_error('無法開啟資料檔，請確認 storage 資料夾可以寫入', 500);
    }
    flock($fp, LOCK_EX);
    $data = json_decode((string) stream_get_contents($fp), true);
    if (!is_array($data)) {
        $data = $default;
    }
    $data = $modify($data);
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return $data;
}

/** 國曆日期 → 儒略日數，用來讓每日學習每天輪替 */
function julian_day_number(int $y, int $m, int $d): int
{
    $a = intdiv(14 - $m, 12);
    $yy = $y + 4800 - $a;
    $mm = $m + 12 * $a - 3;
    return $d + intdiv(153 * $mm + 2, 5) + 365 * $yy + intdiv($yy, 4) - intdiv($yy, 100) + intdiv($yy, 400) - 32045;
}
