<?php
/* ============================================================
   鄉鎮天氣（代為查詢 Open-Meteo，並把結果快取在 storage/cache）
   GET api/weather.php?lat=25.03&lon=121.56   7 天預報（快取 30 分鐘）
   GET api/weather.php?q=礁溪                  地名搜尋（快取 7 天）
   連不上氣象服務時，若有舊的快取資料，會回傳舊資料並標示 stale = true
   ============================================================ */
require __DIR__ . '/../includes/config.php';

const CACHE_DIR = STORAGE_DIR . '/cache';

/** 下載網址內容；優先使用 cURL，沒有安裝時改用 file_get_contents */
function http_get(string $url): ?string
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_USERAGENT => APP_NAME . '/' . APP_VERSION]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body !== false && $code === 200) ? $body : null;
    }
    $ctx = stream_context_create(['http' => ['timeout' => 8, 'header' => 'User-Agent: ' . APP_NAME]]);
    $body = @file_get_contents($url, false, $ctx);
    return $body === false ? null : $body;
}

/** 有快取且未過期就用快取，否則重新下載；下載失敗時退回舊快取 */
function cached_fetch(string $key, string $url, int $ttl): array
{
    if (!is_dir(CACHE_DIR)) {
        mkdir(CACHE_DIR, 0775, true);
    }
    $file = CACHE_DIR . '/' . md5($key) . '.json';
    $age = is_file($file) ? time() - filemtime($file) : PHP_INT_MAX;
    if ($age < $ttl) {
        return ['data' => json_decode(file_get_contents($file), true), 'cached' => true, 'stale' => false, 'fetched_at' => date('m/d H:i', filemtime($file))];
    }
    $body = http_get($url);
    $data = $body ? json_decode($body, true) : null;
    if (is_array($data)) {
        file_put_contents($file, $body, LOCK_EX);
        return ['data' => $data, 'cached' => false, 'stale' => false, 'fetched_at' => date('m/d H:i')];
    }
    if (is_file($file)) {
        return ['data' => json_decode(file_get_contents($file), true), 'cached' => true, 'stale' => true, 'fetched_at' => date('m/d H:i', filemtime($file))];
    }
    json_error('目前無法連線到氣象服務，請確認電腦可以上網', 502);
}

// 地名搜尋
if (isset($_GET['q'])) {
    $q = trim((string) $_GET['q']);
    if ($q === '' || (function_exists('mb_strlen') ? mb_strlen($q) : preg_match_all('/./us', $q)) > 30) {
        json_error('請輸入 1 到 30 個字的地名');
    }
    $url = 'https://geocoding-api.open-meteo.com/v1/search?' . http_build_query(['name' => $q, 'count' => 10, 'language' => 'zh', 'countryCode' => 'TW', 'format' => 'json']);
    $r = cached_fetch("geo:{$q}", $url, 7 * 86400);
    $results = array_map(fn($p) => [
        'name' => $p['name'] ?? '', 'admin1' => $p['admin1'] ?? '', 'admin2' => $p['admin2'] ?? '',
        'latitude' => $p['latitude'], 'longitude' => $p['longitude'],
    ], $r['data']['results'] ?? []);
    json_out(['ok' => true, 'results' => $results]);
}

// 天氣預報
$lat = filter_input(INPUT_GET, 'lat', FILTER_VALIDATE_FLOAT);
$lon = filter_input(INPUT_GET, 'lon', FILTER_VALIDATE_FLOAT);
if ($lat === false || $lat === null || $lon === false || $lon === null || abs($lat) > 90 || abs($lon) > 180) {
    json_error('請提供正確的 lat 與 lon');
}
$lat = round($lat, 3);
$lon = round($lon, 3);
$url = 'https://api.open-meteo.com/v1/forecast?' . http_build_query([
    'latitude' => $lat, 'longitude' => $lon,
    'current'  => 'temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,precipitation',
    'daily'    => 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
    'timezone' => 'Asia/Taipei', 'forecast_days' => 7,
]);
$r = cached_fetch("wx:{$lat},{$lon}", $url, 30 * 60);
json_out(['ok' => true] + $r);
