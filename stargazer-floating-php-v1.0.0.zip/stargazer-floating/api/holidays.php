<?php
/* ============================================================
   GET api/holidays.php?year=2026
   回傳該年的國定假日、補假、補班（官方「政府行政機關辦公日曆表」）
   沒有官方資料的年份回傳 official = false，由瀏覽器依法規推算
   ============================================================ */
require __DIR__ . '/../includes/config.php';

$year = filter_input(INPUT_GET, 'year', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1901, 'max_range' => 2100]]);
if (!$year) {
    json_error('year 必須是 1901 到 2100 之間的整數');
}

$path = DATA_DIR . "/holidays/{$year}.json";
if (!is_file($path)) {
    json_out(['ok' => true, 'year' => $year, 'official' => false, 'days' => new stdClass()]);
}

// 資料格式：{"0101": [1, "開國紀念日"], ...}；1 = 放假，0 = 上班（補班）
json_out([
    'ok'       => true,
    'year'     => $year,
    'official' => true,
    'source'   => '行政院人事行政總處「中華民國政府行政機關辦公日曆表」（政府資料開放平臺）',
    'days'     => read_json_file($path),
]);
