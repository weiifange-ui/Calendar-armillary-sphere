<?php
/* ============================================================
   行程、紀念日、學習進度、天氣地點
   GET  api/planner.php          讀取全部資料
   POST api/planner.php          送出 {"op": "...", ...}，回傳更新後的全部資料
     op = addEvent      {date: "2026-11-10", time: "14:30" 或 "", title}
     op = removeEvent   {id}
     op = addAnniv      {name, type: "solar"|"lunar", m, d, y0}
     op = removeAnniv   {id}
     op = toggleLearned {id: "en:12"}
     op = setWeather    {name, lat, lon}
   ============================================================ */
require __DIR__ . '/../includes/config.php';

const PLANNER_FILE = STORAGE_DIR . '/planner.json';
const EMPTY_STATE  = ['events' => [], 'annivs' => [], 'learned' => [], 'wx' => null];

/** 整理成前端需要的格式（learned 在 JSON 中必須是物件） */
function public_state(array $s): array
{
    return [
        'events'  => array_values($s['events'] ?? []),
        'annivs'  => array_values($s['annivs'] ?? []),
        'learned' => (object) ($s['learned'] ?? []),
        'wx'      => $s['wx'] ?? null,
    ];
}

/** 取出字串欄位，去除前後空白，並檢查長度 */
function text_field(array $in, string $key, int $max, bool $required = true): string
{
    $v = trim((string) ($in[$key] ?? ''));
    if ($required && $v === '') {
        json_error("{$key} 不能是空白");
    }
    // 以「字」計算長度（中文一個字算 1）；沒有安裝 mbstring 擴充時改用正規表示式計算
    $len = function_exists('mb_strlen') ? mb_strlen($v) : preg_match_all('/./us', $v);
    if ($len > $max) {
        json_error("{$key} 最多 {$max} 個字");
    }
    return $v;
}

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
    json_out(['ok' => true, 'state' => public_state(read_json_file(PLANNER_FILE, EMPTY_STATE))]);
}
if ($method !== 'POST') {
    json_error('只接受 GET 或 POST', 405);
}

$in = read_json_body();
$op = $in['op'] ?? '';

$state = update_json_file(PLANNER_FILE, EMPTY_STATE, function (array $s) use ($in, $op): array {
    switch ($op) {
        case 'addEvent':
            // 日期格式：年-月-日，月和日不補零（與前端一致）
            $date = (string) ($in['date'] ?? '');
            if (!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $date, $m) || !checkdate((int) $m[2], (int) $m[3], (int) $m[1])) {
                json_error('date 格式錯誤');
            }
            $time = (string) ($in['time'] ?? '');
            if ($time !== '' && !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time)) {
                json_error('time 格式必須是 HH:MM');
            }
            $s['events'][] = ['id' => bin2hex(random_bytes(6)), 'date' => $date, 'time' => $time, 'title' => text_field($in, 'title', 60)];
            break;

        case 'removeEvent':
            $id = (string) ($in['id'] ?? '');
            $s['events'] = array_values(array_filter($s['events'], fn($e) => $e['id'] !== $id));
            break;

        case 'addAnniv':
            $type = $in['type'] ?? '';
            $m = (int) ($in['m'] ?? 0);
            $d = (int) ($in['d'] ?? 0);
            $y0 = (int) ($in['y0'] ?? 0);
            if (!in_array($type, ['solar', 'lunar'], true) || $m < 1 || $m > 12 || $d < 1 || $d > ($type === 'lunar' ? 30 : 31) || $y0 < 1900 || $y0 > 2100) {
                json_error('紀念日的日期資料不正確');
            }
            $s['annivs'][] = ['id' => bin2hex(random_bytes(6)), 'name' => text_field($in, 'name', 40), 'type' => $type, 'm' => $m, 'd' => $d, 'y0' => $y0];
            break;

        case 'removeAnniv':
            $id = (string) ($in['id'] ?? '');
            $s['annivs'] = array_values(array_filter($s['annivs'], fn($a) => $a['id'] !== $id));
            break;

        case 'toggleLearned':
            $id = (string) ($in['id'] ?? '');
            if (!preg_match('/^(en|code):\d+$/', $id)) {
                json_error('學習項目的編號不正確');
            }
            if (isset($s['learned'][$id])) {
                unset($s['learned'][$id]);
            } else {
                $s['learned'][$id] = time();
            }
            break;

        case 'setWeather':
            $lat = filter_var($in['lat'] ?? null, FILTER_VALIDATE_FLOAT);
            $lon = filter_var($in['lon'] ?? null, FILTER_VALIDATE_FLOAT);
            if ($lat === false || $lon === false || abs($lat) > 90 || abs($lon) > 180) {
                json_error('經緯度不正確');
            }
            $s['wx'] = ['name' => text_field($in, 'name', 40), 'lat' => round($lat, 4), 'lon' => round($lon, 4)];
            break;

        default:
            json_error('不認識的操作：' . $op);
    }
    return $s;
});

json_out(['ok' => true, 'state' => public_state($state)]);
