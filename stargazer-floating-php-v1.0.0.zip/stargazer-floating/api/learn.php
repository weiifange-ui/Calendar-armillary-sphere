<?php
/* ============================================================
   GET api/learn.php?date=2026-11-10&tab=en&offset=0
   依日期挑選當天的英文單字或程式碼範例；offset 用來切換前一則、下一則
   ============================================================ */
require __DIR__ . '/../includes/config.php';

$date   = $_GET['date'] ?? date('Y-m-d');
$tab    = $_GET['tab'] ?? 'en';
$offset = filter_input(INPUT_GET, 'offset', FILTER_VALIDATE_INT) ?? 0;

if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m) || !checkdate((int) $m[2], (int) $m[3], (int) $m[1])) {
    json_error('date 格式必須是 YYYY-MM-DD');
}
if (!in_array($tab, ['en', 'code'], true)) {
    json_error('tab 只能是 en 或 code');
}

$items = read_json_file(DATA_DIR . '/learn.json')[$tab] ?? [];
$total = count($items);
if ($total === 0) {
    json_error('找不到學習資料', 500);
}

// 每天換一則；程式碼分頁往後錯開 7 則，避免兩個分頁剛好同步
$base  = julian_day_number((int) $m[1], (int) $m[2], (int) $m[3]) + ($tab === 'code' ? 7 : 0);
$index = (($base + $offset) % $total + $total) % $total;

json_out(['ok' => true, 'id' => "{$tab}:{$index}", 'index' => $index, 'total' => $total, 'item' => $items[$index]]);
