# 觀星渾天儀・懸空版（PHP 版）

懸浮的 3D 黃銅天文儀，行星依真實軌道運行，並提供今晚觀星條件、天象預報、
國定假日、行程與紀念日、每日學習與鄉鎮天氣。

- 外觀與動畫：瀏覽器端 JavaScript（`assets/`）
- 資料與規則：伺服器端 PHP（`api/`、`data/`、`storage/`）

## 在 XAMPP 上執行

1. 把整個 `stargazer-floating` 資料夾放到 XAMPP 的 `htdocs` 底下，例如
   `C:\xampp\htdocs\stargazer-floating`
2. 開啟 XAMPP Control Panel，按下 Apache 的 **Start**
3. 用瀏覽器開啟 <http://localhost/stargazer-floating/>

需求：PHP 8.1 以上（XAMPP 8.2 以後的版本都符合），並且電腦可以連上網路
（3D 引擎與天氣資料需要從網路下載）。

> 必須透過 `http://localhost/...` 開啟，不能直接雙擊 `index.php`，
> 否則 PHP 不會執行，行程、假日、天氣都無法讀取。

## 資料夾結構

```
stargazer-floating/
├── index.php              頁面入口（輸出 HTML 與版本號）
├── includes/config.php    版本號與共用函式
├── api/
│   ├── holidays.php       國定假日、補假、補班
│   ├── planner.php        行程、紀念日、學習進度、天氣地點
│   ├── learn.php          每日學習
│   └── weather.php        天氣與地名搜尋（含快取）
├── assets/
│   ├── style.css          外觀
│   └── app.js             3D 天文儀、動畫、互動
├── data/
│   ├── holidays/2017.json … 2027.json   官方辦公日曆表
│   └── learn.json         英文單字與程式碼範例
└── storage/               執行時產生的資料（行程、快取），不上傳到 Git
```

`data/`、`storage/`、`includes/` 都放了 `.htaccess`，禁止從網址直接讀取。

## API 一覽

| 網址 | 方法 | 說明 |
|---|---|---|
| `api/holidays.php?year=2026` | GET | 該年的放假與補班日；沒有官方資料時 `official` 為 `false` |
| `api/planner.php` | GET | 讀取行程、紀念日、學習進度、天氣地點 |
| `api/planner.php` | POST | 送出 `{"op": "addEvent", ...}` 等操作，回傳更新後的資料 |
| `api/learn.php?date=2026-11-10&tab=en&offset=0` | GET | 當天的學習內容 |
| `api/weather.php?lat=25.03&lon=121.56` | GET | 7 天天氣預報 |
| `api/weather.php?q=礁溪` | GET | 搜尋地名 |

每個回應都包含 `version` 欄位，HTTP 標頭也有 `X-App-Version`。

## 常見維護工作

**更新版本號**：修改 `includes/config.php` 裡的 `APP_VERSION`，並在 `CHANGELOG.md` 記下這次的變更。
CSS 與 JS 的網址會自動加上 `?v=版本號`，瀏覽器就不會讀到舊的快取。

**加入新一年的國定假日**：行政院公布新年度的辦公日曆表後，在 `data/holidays/` 新增
`年份.json`，格式和現有檔案相同（`"月日": [1 放假 / 0 上班, "說明"]`）。
沒有官方資料的年份，網頁會依現行法規推算並標示「推算」。

**新增學習內容**：在 `data/learn.json` 的 `en` 或 `code` 陣列中加入新項目即可。

**清除天氣快取**：刪除 `storage/cache/` 裡的 `.json` 檔案。
