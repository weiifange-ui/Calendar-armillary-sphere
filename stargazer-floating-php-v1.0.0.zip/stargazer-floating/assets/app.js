/* 觀星渾天儀・懸空版（PHP 版）前端程式：3D 天文儀、動畫與互動；資料由 api/*.php 提供 */

/* ════════════════════════════════════════════════════════════
   天文計算模組
   行星：JPL「Approximate Positions of the Planets」克卜勒軌道根數（J2000 黃道），誤差約 1 角分至 1 度內
   月球：Meeus《Astronomical Algorithms》第 47 章主要項，精度約 0.1°
   所有函式以世界時儒略日（jdUT）為輸入
   ════════════════════════════════════════════════════════════ */
const AST = (() => {
const D2R = Math.PI / 180, R2D = 180 / Math.PI;
const norm = a => ((a % 360) + 360) % 360;
const wrap180 = a => { a = norm(a); return a > 180 ? a - 360 : a; };
const sin = d => Math.sin(d * D2R), cos = d => Math.cos(d * D2R);

// a(AU) e i(°) L(°) ϖ(°) Ω(°) 及每世紀變化率
const ELEM = {
  mercury: [0.38709927, 0.20563593, 7.00497902, 252.25032350, 77.45779628, 48.33076593,
            0.00000037, 0.00001906, -0.00594749, 149472.67411175, 0.16047689, -0.12534081],
  venus:   [0.72333566, 0.00677672, 3.39467605, 181.97909950, 131.60246718, 76.67984255,
            0.00000390, -0.00004107, -0.00078890, 58517.81538729, 0.00268329, -0.27769418],
  earth:   [1.00000261, 0.01671123, -0.00001531, 100.46457166, 102.93768193, 0.0,
            0.00000562, -0.00004392, -0.01294668, 35999.37244981, 0.32327364, 0.0],
  mars:    [1.52371034, 0.09339410, 1.84969142, -4.55343205, -23.94362959, 49.55953891,
            0.00001847, 0.00007882, -0.00813131, 19140.30268499, 0.44441088, -0.29257343],
  jupiter: [5.20288700, 0.04838624, 1.30439695, 34.39644051, 14.72847983, 100.47390909,
            -0.00011607, -0.00013253, -0.00183714, 3034.74612775, 0.21252668, 0.20469106],
  saturn:  [9.53667594, 0.05386179, 2.48599187, 49.95424423, 92.59887831, 113.66242448,
            -0.00125060, -0.00050991, 0.00193609, 1222.49362201, -0.41897216, -0.28867794],
};
const PLANETS = ['mercury', 'venus', 'mars', 'jupiter', 'saturn'];
const cent = jd => (jd - 2451545.0) / 36525;

function elements(p, jd) {
  const E = ELEM[p], T = cent(jd);
  return { a: E[0] + E[6] * T, e: E[1] + E[7] * T, i: E[2] + E[8] * T, L: E[3] + E[9] * T, w: E[4] + E[10] * T, O: E[5] + E[11] * T };
}
function kepler(M, e) {
  M = wrap180(M) * D2R; let E = M + e * Math.sin(M);
  for (let k = 0; k < 8; k++) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
  return E;
}
/* 由軌道根數與平近點角算出日心黃道座標（AU） */
function posFromElements(el, Mdeg) {
  const E = kepler(Mdeg, el.e);
  const xp = el.a * (Math.cos(E) - el.e), yp = el.a * Math.sqrt(1 - el.e * el.e) * Math.sin(E);
  const w = (el.w - el.O) * D2R, O = el.O * D2R, I = el.i * D2R;
  const cw = Math.cos(w), sw = Math.sin(w), cO = Math.cos(O), sO = Math.sin(O), cI = Math.cos(I), sI = Math.sin(I);
  return {
    x: (cw * cO - sw * sO * cI) * xp + (-sw * cO - cw * sO * cI) * yp,
    y: (cw * sO + sw * cO * cI) * xp + (-sw * sO + cw * cO * cI) * yp,
    z: (sw * sI) * xp + (cw * sI) * yp
  };
}
function helio(p, jd) { const el = elements(p, jd); return posFromElements(el, el.L - el.w); }
function orbitPath(p, jd, n = 180) {
  const el = elements(p, jd), pts = [];
  for (let k = 0; k < n; k++) pts.push(posFromElements(el, k * 360 / n));
  return pts;
}
const lenv = v => Math.hypot(v.x, v.y, v.z);
const lonOf = v => norm(Math.atan2(v.y, v.x) * R2D);
const latOf = v => Math.atan2(v.z, Math.hypot(v.x, v.y)) * R2D;
/* 歲差：J2000 黃經 → 當日黃經 */
const precess = jd => { const T = cent(jd); return 1.396971 * T + 0.0003086 * T * T; };
const obliq = jd => 23.439291 - 0.0130042 * cent(jd);

/* 行星地心位置：J2000 黃經緯、距離（AU）、日心距 */
function geoPlanet(p, jd, earth) {
  earth = earth || helio('earth', jd);
  let h = helio(p, jd), g = { x: h.x - earth.x, y: h.y - earth.y, z: h.z - earth.z }, d = lenv(g);
  // 光行時修正
  const tau = d * 0.0057755183;
  h = helio(p, jd - tau); g = { x: h.x - earth.x, y: h.y - earth.y, z: h.z - earth.z }; d = lenv(g);
  return { lon: lonOf(g), lat: latOf(g), dist: d, r: lenv(h), vec: g };
}
function geoSun(jd, earth) {
  earth = earth || helio('earth', jd);
  return { lon: norm(lonOf(earth) + 180 - 20.4898 / 3600 / lenv(earth)), lat: -latOf(earth), dist: lenv(earth) };
}
/* 月球：當日黃道的地心黃經緯（°）與距離（km） */
function moon(jd) {
  const T = cent(jd);
  const Lp = 218.3164477 + 481267.88123421 * T - 0.0015786 * T * T;
  const D = 297.8501921 + 445267.1114034 * T - 0.0018819 * T * T;
  const M = 357.5291092 + 35999.0502909 * T - 0.0001536 * T * T;
  const Mp = 134.9633964 + 477198.8675055 * T + 0.0087414 * T * T;
  const F = 93.272095 + 483202.0175233 * T - 0.0036539 * T * T;
  const Ee = 1 - 0.002516 * T;
  // [D, M, M', F, 經度係數(10^-6°), 距離係數(0.001km)]
  const LR = [[0,0,1,0,6288774,-20905355],[2,0,-1,0,1274027,-3699111],[2,0,0,0,658314,-2955968],[0,0,2,0,213618,-569925],
    [0,1,0,0,-185116,48888],[0,0,0,2,-114332,-3149],[2,0,-2,0,58793,246158],[2,-1,-1,0,57066,-152138],[2,0,1,0,53322,-170733],
    [2,-1,0,0,45758,-204586],[0,1,-1,0,-40923,-129620],[1,0,0,0,-34720,108743],[0,1,1,0,-30383,104755],[2,0,0,-2,15327,10321],
    [0,0,1,2,-12528,0],[0,0,1,-2,10980,79661],[4,0,-1,0,10675,-34782],[0,0,3,0,10034,-23210],[4,0,-2,0,8548,-21636],
    [2,1,-1,0,-7888,24208],[2,1,0,0,-6766,30824],[1,0,-1,0,-5163,-8379],[1,1,0,0,4987,-16675],[2,-1,1,0,4036,-12831],
    [2,0,2,0,3994,-10445],[4,0,0,0,3861,-11650],[2,0,-3,0,3665,14403],[0,1,-2,0,-2689,-7003],[2,0,-1,2,-2602,0],
    [2,-1,-2,0,2390,10056],[1,0,1,0,-2348,6322],[2,-2,0,0,2236,-9884]];
  const B = [[0,0,0,1,5128122],[0,0,1,1,280602],[0,0,1,-1,277693],[2,0,0,-1,173237],[2,0,-1,1,55413],[2,0,-1,-1,46271],
    [2,0,0,1,32573],[0,0,2,1,17198],[2,0,1,-1,9266],[0,0,2,-1,8822],[2,-1,0,-1,8216],[2,0,-2,-1,4324],[2,0,1,1,4200],
    [2,1,0,-1,-3359],[2,-1,-1,1,2463],[2,-1,0,1,2211],[2,-1,-1,-1,2065],[0,1,-1,-1,-1870],[4,0,-1,-1,1828],[0,1,0,1,-1794]];
  let sl = 0, sr = 0, sb = 0;
  for (const [d, m, mp, f, l, r] of LR) {
    const arg = d * D + m * M + mp * Mp + f * F, k = Math.abs(m) === 1 ? Ee : Math.abs(m) === 2 ? Ee * Ee : 1;
    sl += l * k * sin(arg); sr += r * k * cos(arg);
  }
  for (const [d, m, mp, f, b] of B) {
    const k = Math.abs(m) === 1 ? Ee : Math.abs(m) === 2 ? Ee * Ee : 1;
    sb += b * k * sin(d * D + m * M + mp * Mp + f * F);
  }
  const A1 = 119.75 + 131.849 * T, A2 = 53.09 + 479264.29 * T, A3 = 313.45 + 481266.484 * T;
  sl += 3958 * sin(A1) + 1962 * sin(Lp - F) + 318 * sin(A2);
  sb += -2235 * sin(Lp) + 382 * sin(A3) + 175 * sin(A1 - F) + 175 * sin(A1 + F) + 127 * sin(Lp - Mp) - 115 * sin(Lp + Mp);
  return { lon: norm(Lp + sl / 1e6), lat: sb / 1e6, dist: 385000.56 + sr / 1000 };
}
/* 黃道 → 赤道 */
function eclToEq(lon, lat, eps) {
  const x = cos(lat) * cos(lon), y = cos(lat) * sin(lon) * cos(eps) - sin(lat) * sin(eps), z = cos(lat) * sin(lon) * sin(eps) + sin(lat) * cos(eps);
  return { ra: norm(Math.atan2(y, x) * R2D), dec: Math.asin(Math.max(-1, Math.min(1, z))) * R2D };
}
function eqToEcl(ra, dec, eps) {
  const x = cos(dec) * cos(ra), y = cos(dec) * sin(ra) * cos(eps) + sin(dec) * sin(eps), z = -cos(dec) * sin(ra) * sin(eps) + sin(dec) * cos(eps);
  return { lon: norm(Math.atan2(y, x) * R2D), lat: Math.asin(z) * R2D };
}
function gmst(jd) { const T = cent(jd); return norm(280.46061837 + 360.98564736629 * (jd - 2451545) + 0.000387933 * T * T); }
function altAz(ra, dec, lat, lst) {
  const H = lst - ra;
  const alt = Math.asin(sin(lat) * sin(dec) + cos(lat) * cos(dec) * cos(H)) * R2D;
  const az = norm(Math.atan2(-cos(dec) * sin(H), sin(dec) * cos(lat) - cos(dec) * cos(H) * sin(lat)) * R2D);
  return { alt, az };
}
/* 任一天體在當日赤道座標（ra/dec，°），月球另附距離 */
function bodyEq(key, jd, cache) {
  const eps = obliq(jd), pr = precess(jd);
  if (key === 'moon') { const m = moon(jd); const q = eclToEq(m.lon, m.lat, eps); q.dist = m.dist; return q; }
  const earth = (cache && cache.earth) || helio('earth', jd);
  if (key === 'sun') { const s = geoSun(jd, earth); return eclToEq(s.lon + pr, s.lat, eps); }
  const g = geoPlanet(key, jd, earth);
  return eclToEq(g.lon + pr, g.lat, eps);
}
/* 地平高度（°）：月球含視差修正 */
function altitude(key, jd, loc) {
  const q = bodyEq(key, jd), lst = gmst(jd) + loc.lon;
  let { alt, az } = altAz(q.ra, q.dec, loc.lat, lst);
  if (key === 'moon') alt -= Math.asin(6378.14 / q.dist) * R2D * cos(alt);
  return { alt, az };
}
const H0 = { sun: -0.833, moon: -0.833, planet: -0.567 };   // 月球高度已扣除視差，故與太陽同為上緣切地平
/* 在 [t0,t1] 內尋找高度穿越 h 的時刻 */
function crossings(fn, t0, t1, h, step = 10 / 1440) {
  const out = []; let pt = t0, pv = fn(t0) - h;
  for (let t = t0 + step; t <= t1 + 1e-9; t += step) {
    const v = fn(t) - h;
    if ((pv < 0) !== (v < 0)) {
      let a = pt, b = t, fa = pv;
      for (let k = 0; k < 18; k++) { const m = (a + b) / 2, fm = fn(m) - h; if ((fa < 0) === (fm < 0)) { a = m; fa = fm; } else b = m; }
      out.push({ t: (a + b) / 2, rise: pv < 0 });
    }
    pt = t; pv = v;
  }
  return out;
}
/* 星等（Meeus 第 41 章近似式） */
function magnitude(p, g, earthDist) {
  const r = g.r, d = g.dist, R = earthDist;
  const i = Math.acos(Math.max(-1, Math.min(1, (r * r + d * d - R * R) / (2 * r * d)))) * R2D, l = 5 * Math.log10(r * d);
  switch (p) {
    case 'mercury': return -0.42 + l + 0.038 * i - 0.000273 * i * i + 0.000002 * i * i * i;
    case 'venus': return -4.40 + l + 0.0009 * i + 0.000239 * i * i - 0.00000065 * i * i * i;
    case 'mars': return -1.52 + l + 0.016 * i;
    case 'jupiter': return -9.40 + l + 0.005 * i;
    case 'saturn': return -8.88 + l + 0.044 * i;
  }
}
/* 月球地形視差：地面觀測者看到的月球赤道座標 */
function topoMoon(jd, loc) {
  const q = bodyEq('moon', jd), lst = gmst(jd) + loc.lon, H = lst - q.ra;
  const sp = Math.asin(6378.14 / q.dist), u = Math.atan(0.99664719 * Math.tan(loc.lat * D2R));
  const rs = 0.99664719 * Math.sin(u), rc = Math.cos(u);
  const dA = Math.atan2(-rc * Math.sin(sp) * sin(H), cos(q.dec) - rc * Math.sin(sp) * cos(H));
  const dec = Math.atan2((sin(q.dec) - rs * Math.sin(sp)) * Math.cos(dA), cos(q.dec) - rc * Math.sin(sp) * cos(H)) * R2D;
  return { ra: q.ra + dA * R2D, dec, dist: q.dist };
}
function sep(ra1, d1, ra2, d2) {
  const c = sin(d1) * sin(d2) + cos(d1) * cos(d2) * cos(ra1 - ra2);
  return Math.acos(Math.max(-1, Math.min(1, c))) * R2D;
}
return { D2R, R2D, norm, wrap180, ELEM, PLANETS, helio, orbitPath, geoPlanet, geoSun, moon, eclToEq, eqToEcl, gmst, altAz, bodyEq,
  altitude, H0, crossings, magnitude, topoMoon, sep, precess, obliq, lonOf, latOf, lenv };
})();


/* ════════════════════════════════════════════════════════════
   觀星資訊：夜晚條件、行星可見時段、天象事件（全部即時計算）
   ════════════════════════════════════════════════════════════ */
const SKY = (() => {
const A = AST;
const { norm, wrap180, R2D } = A;
const TZ = 8 / 24;                       // 台灣時間 UTC+8
const PN = { mercury: '水星', venus: '金星', mars: '火星', jupiter: '木星', saturn: '土星', moon: '月球', sun: '太陽' };
const DIRS = ['北', '東北', '東', '東南', '南', '西南', '西', '西北'];
const dirName = az => DIRS[Math.round(norm(az) / 45) % 8];

/* 流星雨：極大時的太陽黃經（J2000，依國際流星組織 IMO）與每小時天頂流量 */
const SHOWERS = [
  { name: '象限儀座流星雨', lam: 283.15, zhr: 110 },
  { name: '天琴座流星雨', lam: 32.32, zhr: 18 },
  { name: '寶瓶座η流星雨', lam: 45.5, zhr: 50 },
  { name: '英仙座流星雨', lam: 140.0, zhr: 100 },
  { name: '獵戶座流星雨', lam: 208.0, zhr: 20 },
  { name: '獅子座流星雨', lam: 235.27, zhr: 15 },
  { name: '雙子座流星雨', lam: 262.2, zhr: 150 },
  { name: '小熊座流星雨', lam: 270.7, zhr: 10 },
];

/* 各量（J2000 黃經） */
const sunLon = jd => A.geoSun(jd).lon;
const moonLon = jd => norm(A.moon(jd).lon - A.precess(jd));
const pLon = (p, jd) => A.geoPlanet(p, jd).lon;
function elong(p, jd) {
  const e = A.helio('earth', jd), g = A.geoPlanet(p, jd, e), s = { x: -e.x, y: -e.y, z: -e.z };
  const c = (g.vec.x * s.x + g.vec.y * s.y + g.vec.z * s.z) / (A.lenv(g.vec) * A.lenv(s));
  return Math.acos(Math.max(-1, Math.min(1, c))) * R2D;
}
/* 在 [a,b] 內以二分法求 f 的零點（f 需在端點異號，且數值不跨越 ±180 的接縫） */
function root(f, a, b) {
  let fa = f(a);
  for (let k = 0; k < 30; k++) { const m = (a + b) / 2, fm = f(m); if ((fa < 0) === (fm < 0)) { a = m; fa = fm; } else b = m; }
  return (a + b) / 2;
}
function scanCross(f, jd0, jd1, step, cb) {
  let pt = jd0, pv = f(jd0);
  for (let t = jd0 + step; t <= jd1 + 1e-9; t += step) {
    const v = f(t);
    if ((pv < 0) !== (v < 0) && Math.abs(pv) < 90 && Math.abs(v) < 90) cb(root(f, pt, t), pv < 0);
    pt = t; pv = v;
  }
}

/* ── 月食：滿月時月球與地影的幾何 ── */
function lunarEclipse(t, loc) {
  const m = A.moon(t), e = A.helio('earth', t), R = A.lenv(e);
  const pm = Math.asin(6378.14 / m.dist) * R2D, sm = Math.asin(1737.4 / m.dist) * R2D;
  const ss = 0.2666 / R, ps = 0.00244 / R;
  const umb = 1.02 * (pm + ps - ss), pen = 1.02 * (pm + ps + ss);
  const g = Math.abs(m.lat) * Math.cos(5.145 * A.D2R);
  if (g > pen + sm) return null;
  const v = 0.5 / 24;                       // 月球相對地影約每小時 0.5°
  let type, half;
  if (g < umb - sm) { type = '月全食'; half = Math.sqrt((umb + sm) ** 2 - g * g) / v; }
  else if (g < umb + sm) { type = '月偏食'; half = Math.sqrt((umb + sm) ** 2 - g * g) / v; }
  else { type = '半影月食'; half = Math.sqrt((pen + sm) ** 2 - g * g) / v; }
  const mag = (umb + sm - g) / (2 * sm);
  const up = dt => A.altitude('moon', t + dt, loc).alt > -0.8;
  const a = up(-half), b = up(0), c = up(half);
  const vis = a && b && c ? '全程可見' : (a || b || c) ? '可見部分過程' : '台灣不可見';
  return { type, mag, vis, visible: a || b || c, t };
}
/* ── 日食：新月時在觀測地以月球地形視差搜尋最小角距 ── */
function solarEclipse(t, loc) {
  if (Math.abs(A.moon(t).lat) > 1.6) return null;
  let best = null, first = null, last = null;
  for (let dt = -0.18; dt <= 0.18; dt += 1 / 1440) {
    const jd = t + dt, s = A.bodyEq('sun', jd), lst = A.gmst(jd) + loc.lon;
    const sa = A.altAz(s.ra, s.dec, loc.lat, lst).alt;
    if (sa < -0.5) continue;
    const m = A.topoMoon(jd, loc), R = A.lenv(A.helio('earth', jd));
    const ss = 0.2666 / R, sm = Math.asin(1737.4 / (m.dist - 6378 * Math.sin(Math.max(0, sa) * A.D2R))) * R2D;
    const d = A.sep(s.ra, s.dec, m.ra, m.dec);
    if (d < ss + sm) { if (first === null) first = jd; last = jd; }
    if (!best || d < best.d) best = { d, ss, sm, jd };
  }
  if (!best || best.d >= best.ss + best.sm) return null;
  const { d, ss, sm } = best;
  const type = d < Math.abs(sm - ss) ? (sm > ss ? '日全食' : '日環食') : '日偏食';
  return { type, mag: (ss + sm - d) / (2 * ss), t: best.jd, start: first, end: last, visible: true };
}

/* ── 事件掃描（jdUT 範圍） ── */
function events(jd0, jd1, loc) {
  const ev = [];
  const push = (t, type, text, extra = {}) => ev.push({ t, type, text, ...extra });
  // 月相與日月食
  scanCross(t => wrap180(moonLon(t) - sunLon(t)), jd0, jd1, 0.5, t => {
    push(t, 'phase', '新月', { icon: 'new' });
    const se = solarEclipse(t, loc);
    if (se) push(se.t, 'eclipse', `${se.type}（食分約 ${se.mag.toFixed(2)}）`, { detail: se, major: true });
  });
  scanCross(t => wrap180(moonLon(t) - sunLon(t) - 180), jd0, jd1, 0.5, t => {
    push(t, 'phase', '滿月', { icon: 'full' });
    const le = lunarEclipse(t, loc);
    if (le && le.visible && le.type !== '半影月食') push(t, 'eclipse', `${le.type}（${le.vis}）`, { detail: le, major: true });
    else if (le && le.visible) push(t, 'eclipse', '半影月食（月面僅微暗，不易察覺）', { detail: le });
  });
  // 流星雨極大
  for (const s of SHOWERS) scanCross(t => wrap180(sunLon(t) - s.lam), jd0, jd1, 1, (t) => {
    push(t, 'meteor', `${s.name}極大（理想條件下每小時約 ${s.zhr} 顆）`, { major: s.zhr >= 50 });
  });
  for (const p of A.PLANETS) {
    // 月球合行星（只列可觀測者）
    scanCross(t => wrap180(moonLon(t) - pLon(p, t)), jd0, jd1, 0.5, (t, up) => {
      if (!up) return;
      const sep = Math.abs(A.moon(t).lat - A.geoPlanet(p, t).lat);
      if (sep < 5 && elong(p, t) > 15) push(t, 'conj', `月球合${PN[p]}（相距約 ${sep.toFixed(1)}°）`, { body: p });
    });
    // 衝：外行星最亮、整夜可見
    if (['mars', 'jupiter', 'saturn'].includes(p))
      scanCross(t => wrap180(pLon(p, t) - sunLon(t) - 180), jd0, jd1, 1, (t, up) => { if (up) push(t, 'opp', `${PN[p]}衝日（最亮，整夜可見）`, { body: p, major: true }); });
    // 留：開始／結束逆行
    scanCross(t => wrap180(pLon(p, t + 0.5) - pLon(p, t - 0.5)), jd0, jd1, 1, (t, up) =>
      push(t, 'station', up ? `${PN[p]}結束逆行，恢復順行` : `${PN[p]}開始逆行`, { body: p }));
    // 東大距、西大距
    if (p === 'mercury' || p === 'venus') {
      let a = elong(p, jd0 - 1), b = elong(p, jd0);
      for (let t = jd0 + 1; t <= jd1 + 1; t += 1) {
        const c = elong(p, t);
        if (b > a && b >= c) {
          let lo = t - 2, hi = t;
          for (let k = 0; k < 40; k++) { const m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3; if (elong(p, m1) < elong(p, m2)) lo = m1; else hi = m2; }
          const tm = (lo + hi) / 2, east = wrap180(pLon(p, tm) - sunLon(tm)) > 0;
          if (tm >= jd0 && tm <= jd1) push(tm, 'elong', `${PN[p]}${east ? '東大距（傍晚西方天空）' : '西大距（清晨東方天空）'}，距太陽 ${elong(p, tm).toFixed(0)}°`, { body: p, major: p === 'mercury' });
        }
        a = b; b = c;
      }
    }
  }
  // 行星合行星
  for (let i = 0; i < 5; i++) for (let j = i + 1; j < 5; j++) {
    const p = A.PLANETS[i], q = A.PLANETS[j];
    scanCross(t => wrap180(pLon(p, t) - pLon(q, t)), jd0, jd1, 1, t => {
      const sep = Math.abs(A.geoPlanet(p, t).lat - A.geoPlanet(q, t).lat);
      if (sep < 3 && elong(p, t) > 12) push(t, 'conj', `${PN[p]}合${PN[q]}（相距約 ${sep.toFixed(1)}°）`, { body: p, major: sep < 1 });
    });
  }
  return ev.sort((a, b) => a.t - b.t);
}

/* ── 一夜的觀測條件：night0 為當地傍晚所屬日期 00:00 的儒略日（民用時） ── */
function night(jdLocalDate, loc) {
  const t0 = jdLocalDate + 0.5 - TZ, t1 = t0 + 1;
  const sunAlt = t => A.altitude('sun', t, loc).alt, moonAlt = t => A.altitude('moon', t, loc).alt;
  const sunX = A.crossings(sunAlt, t0, t1, A.H0.sun, 15 / 1440);
  const astro = A.crossings(sunAlt, t0, t1, -18, 15 / 1440);
  const naut = A.crossings(sunAlt, t0, t1, -6, 15 / 1440);
  const moonX = A.crossings(moonAlt, t0, t1, A.H0.moon, 15 / 1440);
  const pick = (arr, rise) => { const x = arr.find(c => c.rise === rise); return x ? x.t : null; };
  const sunset = pick(sunX, false), sunrise = pick(sunX, true), dusk = pick(astro, false), dawn = pick(astro, true);
  const civDusk = pick(naut, false), civDawn = pick(naut, true);
  const mid = (dusk && dawn) ? (dusk + dawn) / 2 : t0 + 0.5;
  const E = norm(A.moon(mid).lon - A.precess(mid) - sunLon(mid)), illum = (1 - Math.cos(E * A.D2R)) / 2;
  const segs = []; let darkMin = 0;
  if (dusk && dawn && dawn > dusk) {
    let cur = null;
    for (let t = dusk; t <= dawn + 1e-9; t += 5 / 1440) {
      const ok = illum < 0.08 || moonAlt(t) < A.H0.moon;
      if (ok) { darkMin += 5; if (!cur) cur = { a: t, b: t }; cur.b = t; } else if (cur) { segs.push(cur); cur = null; }
    }
    if (cur) segs.push(cur);
  }
  const grade = darkMin >= 360 ? 4 : darkMin >= 180 ? 3 : darkMin >= 60 ? 2 : 1;
  return { t0, t1, sunset, sunrise, dusk, dawn, civDusk, civDawn, moonrise: pick(moonX, true), moonset: pick(moonX, false), E, illum, segs, darkMin, grade };
}
/* ── 行星當夜可見時段 ── */
function planetNight(p, n, loc) {
  const alt = t => A.altitude(p, t, loc);
  const x = A.crossings(t => alt(t).alt, n.t0, n.t1, A.H0.planet, 15 / 1440);
  const a = n.civDusk || n.sunset || n.t0, b = n.civDawn || n.sunrise || n.t1;
  const segs = []; let cur = null, best = null;
  for (let t = a; t <= b + 1e-9; t += 10 / 1440) {
    const h = alt(t), ok = h.alt > 5;
    if (ok) { if (!cur) cur = { a: t, b: t }; cur.b = t; if (!best || h.alt > best.alt) best = { t, alt: h.alt, az: h.az }; }
    else if (cur) { segs.push(cur); cur = null; }
  }
  if (cur) segs.push(cur);
  const mid = (a + b) / 2, e = A.helio('earth', mid), g = A.geoPlanet(p, mid, e);
  return { rise: (x.find(c => c.rise) || {}).t, set: (x.find(c => !c.rise) || {}).t, segs, best, dir: best ? dirName(best.az) : '', elong: elong(p, mid),
    mag: A.magnitude(p, g, A.lenv(e)), retro: wrap180(pLon(p, mid + 0.5) - pLon(p, mid - 0.5)) < 0, dist: g.dist };
}
return { TZ, PN, SHOWERS, events, night, planetNight, lunarEclipse, solarEclipse, elong, dirName, sunLon, moonLon };
})();


(() => {
'use strict';
const $ = id => document.getElementById(id);
if (typeof Solar === 'undefined') { $('panel').innerHTML = '<p class="err">曆法函式庫沒有載入，請確認網路連線後重新整理頁面。</p>'; $('loading').textContent = ''; return; }
const A = AST, S = SKY;
const D2R = Math.PI / 180, TAU = Math.PI * 2, deg = d => d * D2R;
const YEAR_MIN = 1901, YEAR_MAX = 2099, TZ = 8 / 24;
const PLANE_Y = 1.15;                         // 行星軌道平面距盤面的高度
const dispR = r => 1.5 * Math.pow(r, 0.4);    // 軌道半徑壓縮：真實 AU → 儀器尺寸（保留方向與偏心）
const norm = A.norm, wrap180 = A.wrap180, clamp = (v, a, b) => Math.max(a, Math.min(b, v)), pad = n => String(n).padStart(2, '0');

/* ── 名稱與顏色 ── */
const BODY = {
  mercury: { name: '水星', hex: 0xbdb6ab, size: .11 }, venus: { name: '金星', hex: 0xf0dca0, size: .17 },
  earth: { name: '地球', hex: 0x6b95e0, size: .19 }, mars: { name: '火星', hex: 0xe0704a, size: .14 },
  jupiter: { name: '木星', hex: 0xdcb68c, size: .32 }, saturn: { name: '土星', hex: 0xe8d39a, size: .27 },
  moon: { name: '月球', hex: 0xd9dee6 }, sun: { name: '太陽', hex: 0xffc95a },
};
const ORDER = ['mercury', 'venus', 'earth', 'mars', 'jupiter', 'saturn'];
/* 黃道星座：IAU 星座邊界與黃道（J2000）的交點 */
const ZODIAC = [['雙魚座', 'Pisces', 350.34, 27.38], ['牡羊座', 'Aries', 27.38, 52.10], ['金牛座', 'Taurus', 52.10, 88.82], ['雙子座', 'Gemini', 88.82, 116.68],
  ['巨蟹座', 'Cancer', 116.68, 136.72], ['獅子座', 'Leo', 136.72, 172.54], ['處女座', 'Virgo', 172.54, 216.50], ['天秤座', 'Libra', 216.50, 239.74],
  ['天蠍座', 'Scorpius', 239.74, 246.32], ['蛇夫座', 'Ophiuchus', 246.32, 264.92], ['射手座', 'Sagittarius', 264.92, 298.34], ['摩羯座', 'Capricornus', 298.34, 326.18], ['水瓶座', 'Aquarius', 326.18, 350.34]];
const zodiacOf = lon => ZODIAC.find(z => z[2] < z[3] ? lon >= z[2] && lon < z[3] : lon >= z[2] || lon < z[3]);
const TERM = ['春分', '清明', '穀雨', '立夏', '小滿', '芒種', '夏至', '小暑', '大暑', '立秋', '處暑', '白露', '秋分', '寒露', '霜降', '立冬', '小雪', '大雪', '冬至', '小寒', '大寒', '立春', '雨水', '驚蟄'];
/* 亮星（J2000 赤經、赤緯、星等） */
const STARS = [['天狼星', 101.287, -16.716, -1.46], ['老人星', 95.988, -52.696, -0.74], ['大角星', 213.915, 19.182, -0.05], ['織女星', 279.234, 38.784, 0.03],
  ['五車二', 79.172, 45.998, 0.08], ['參宿七', 78.634, -8.202, 0.13], ['南河三', 114.825, 5.225, 0.34], ['參宿四', 88.793, 7.407, 0.5], ['牛郎星', 297.696, 8.868, 0.77],
  ['畢宿五', 68.98, 16.509, 0.85], ['心宿二', 247.352, -26.432, 1.0], ['角宿一', 201.298, -11.161, 0.97], ['北河三', 116.329, 28.026, 1.14], ['北落師門', 344.413, -29.622, 1.16],
  ['天津四', 310.358, 45.28, 1.25], ['軒轅十四', 152.093, 11.967, 1.35], ['北極星', 37.955, 89.264, 1.98]];
const LOCS = [['台北市區', 25.033, 121.565], ['陽明山擎天崗', 25.167, 121.574], ['合歡山暗空公園', 24.142, 121.273], ['阿里山', 23.511, 120.805], ['台中', 24.148, 120.674],
  ['高雄', 22.627, 120.301], ['墾丁', 21.947, 120.799], ['花蓮', 23.976, 121.606], ['台東鹿野', 22.913, 121.136], ['澎湖', 23.566, 119.578]];
let loc = { name: LOCS[0][0], lat: LOCS[0][1], lon: LOCS[0][2] };
const WEEK = '日一二三四五六', LMONTH = ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '臘'];
const GAN = '甲乙丙丁戊己庚辛壬癸', ZHI = '子丑寅卯辰巳午未申酉戌亥';

/* ── 日期工具：本地民用儒略日（.5 為午夜） ── */
function jdOf(y, m, d) { if (m <= 2) { y -= 1; m += 12; } const a = Math.floor(y / 100), b = 2 - a + Math.floor(a / 4); return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524.5; }
function ymdOf(jd) {
  const z = Math.floor(jd + 0.5), f = jd + 0.5 - z, a0 = Math.floor((z - 1867216.25) / 36524.25), a = z + 1 + a0 - Math.floor(a0 / 4), b = a + 1524;
  const c = Math.floor((b - 122.1) / 365.25), d = Math.floor(365.25 * c), e = Math.floor((b - d) / 30.6001);
  const day = b - d - Math.floor(30.6001 * e), m = e < 14 ? e - 1 : e - 13, y = m > 2 ? c - 4716 : c - 4715;
  const mins = Math.round(f * 1440) % 1440;
  return { y, m, d: day, h: Math.floor(mins / 60), mi: mins % 60 };
}
const isLeap = y => (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
const dim = (y, m) => [31, isLeap(y) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1];
const sameDay = (a, b) => a && b && a.y === b.y && a.m === b.m && a.d === b.d;
const nightOf = T => ymdOf(T - 0.5);                     // 中午到隔天中午屬於同一個「觀測夜」
const fmtHM = jdUT => { if (jdUT == null) return '—'; const t = ymdOf(jdUT + TZ); return `${pad(t.h)}:${pad(t.mi)}`; };
const fmtMD = jdUT => { const t = ymdOf(jdUT + TZ); return `${t.m}/${t.d}`; };
const nowLocal = () => { const n = new Date(); return jdOf(n.getFullYear(), n.getMonth() + 1, n.getDate()) + (n.getHours() * 60 + n.getMinutes()) / 1440; };

/* ── 快取 ── */
const nightCache = new Map(), evCache = new Map();
const locKey = () => `${loc.lat.toFixed(3)},${loc.lon.toFixed(3)}`;
function nightInfo(d) {
  const k = `${locKey()}|${d.y}-${d.m}-${d.d}`;
  if (!nightCache.has(k)) nightCache.set(k, S.night(jdOf(d.y, d.m, d.d), loc));
  return nightCache.get(k);
}
function eventsFor(jd0, jd1) {
  const k = `${locKey()}|${jd0}|${jd1}`;
  if (!evCache.has(k)) { if (evCache.size > 40) evCache.clear(); evCache.set(k, S.events(jd0 - TZ, jd1 - TZ, loc)); }
  return evCache.get(k);
}
const shortOf = e => e.type === 'eclipse' ? e.text.slice(0, 3) : e.type === 'meteor' ? '流星雨' : e.type === 'opp' ? BODY[e.body].name + '衝'
  : e.type === 'elong' ? BODY[e.body].name + '大距' : e.type === 'conj' ? (e.text.startsWith('月球') ? '月合' + e.text.slice(3, 5) : '行星相合') : e.type === 'station' ? BODY[e.body].name + '留' : '';

/* ════════════════════════════════════════════════════════════
   某一時刻的太陽系狀態
   ════════════════════════════════════════════════════════════ */
function snapshot(T) {
  const jd = T - TZ, earth = A.helio('earth', jd), pr = A.precess(jd);
  const st = { jd, T, helio: { earth }, geo: {} };
  for (const p of A.PLANETS) { st.helio[p] = A.helio(p, jd); st.geo[p] = A.geoPlanet(p, jd, earth); }
  const m = A.moon(jd); st.geo.moon = { lon: norm(m.lon - pr), lat: m.lat, dist: m.dist };
  st.geo.sun = A.geoSun(jd, earth);
  st.E = norm(st.geo.moon.lon - st.geo.sun.lon);
  st.gmst = A.gmst(jd);
  return st;
}

/* ════════════════════════════════════════════════════════════
   3D 場景
   ════════════════════════════════════════════════════════════ */
const stage = $('stage'), glBox = $('gl');
/* 畫質：解析度、陰影、閒置時的更新頻率 */
const QUALITY = {
  high: { pr: 2,   shadow: 2048, idleFps: 30 },
  mid:  { pr: 1.5, shadow: 1024, idleFps: 20 },
  low:  { pr: 1,   shadow: 0,    idleFps: 12 },
};
let qName = (() => { try { return localStorage.getItem('orrery-quality') || 'mid'; } catch (e) { return 'mid'; } })();
if (!QUALITY[qName]) qName = 'mid';
let Q = QUALITY[qName];
let renderer = null, scene, camera, controls;
try { if (typeof THREE === 'undefined' || !THREE.OrbitControls) throw 0; renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true }); }
catch (e) { $('loading').innerHTML = '<p class="err">這個瀏覽器無法顯示 3D 天文儀（需要 WebGL），右側的觀星資訊仍可正常使用。</p>'; }
const tex = {}, refs = { pickables: [], gears: {}, bodies: {}, beads: {} };
let mats = {};
const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const toScene = v => { const r = Math.hypot(v.x, v.y, v.z), s = dispR(r) / r; return new THREE.Vector3(v.x * s, PLANE_Y + v.z * s, -v.y * s); };
const eclDir = (lon, lat) => new THREE.Vector3(Math.cos(deg(lat)) * Math.cos(deg(lon)), Math.sin(deg(lat)), -Math.cos(deg(lat)) * Math.sin(deg(lon)));

const dust = $('dust'), dctx = dust.getContext('2d'); let stars = [];
function canvasTex(w, h, draw, srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.encoding = THREE.sRGBEncoding;
  t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  t.userData.canvas = c;
  return t;
}
function rnd(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }
function brushedTex(seed, repeatX) {      // 拉絲紋：沿長度方向的細長刮痕，作為粗糙度與凹凸貼圖
  const t = canvasTex(1024, 256, (ctx, w, h) => {
    ctx.fillStyle = '#5c5c5c'; ctx.fillRect(0, 0, w, h);
    const r = rnd(seed);
    for (let i = 0; i < 2600; i++) {
      const v = 40 + r() * 90 | 0;
      ctx.fillStyle = `rgba(${v},${v},${v},${.3 + r() * .5})`;
      ctx.fillRect(r() * w - 300, r() * h, 120 + r() * 700, r() < .92 ? 1 : 2);
    }
    // 金屬漆中的細小亮片：粗糙度忽高忽低的微點，在光下閃爍
    for (let i = 0; i < 12000; i++) { const v = r() < .5 ? 25 : 160; ctx.fillStyle = `rgb(${v},${v},${v})`; ctx.fillRect(r() * w, r() * h, 1, 1); }
  }, false);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeatX, 1);
  return t;
}
function hammeredTex() {                  // 錘紋：大量圓形淺凹
  const t = canvasTex(1024, 1024, (ctx, w, h) => {
    ctx.fillStyle = '#808080'; ctx.fillRect(0, 0, w, h);
    const r = rnd(21);
    for (let i = 0; i < 2400; i++) {
      const x = r() * w, y = r() * h, rr = 10 + r() * 22;
      const g = ctx.createRadialGradient(x - rr * .2, y - rr * .2, 0, x, y, rr);
      g.addColorStop(0, 'rgba(60,60,60,.55)'); g.addColorStop(.7, 'rgba(120,120,120,.25)'); g.addColorStop(1, 'rgba(170,170,170,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, rr, 0, TAU); ctx.fill();
    }
  }, false);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 3);
  return t;
}
function woodTex() {                      // 桃花心木：暗紅底色與波動木紋
  const t = canvasTex(1024, 512, (ctx, w, h) => {
    ctx.fillStyle = '#43140c'; ctx.fillRect(0, 0, w, h);
    const r = rnd(33);
    for (let i = 0; i < 260; i++) {
      const y0 = r() * h, amp = 2 + r() * 8, fq = .004 + r() * .01, ph = r() * 9;
      ctx.strokeStyle = r() < .5 ? `rgba(30,6,4,${.2 + r() * .35})` : `rgba(150,60,35,${.12 + r() * .2})`;
      ctx.lineWidth = .6 + r() * 2.4;
      ctx.beginPath();
      for (let x = 0; x <= w; x += 8) { const y = y0 + Math.sin(x * fq + ph) * amp + Math.sin(x * fq * 3.1 + ph) * amp * .3; x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
      ctx.stroke();
    }
    for (let i = 0; i < 90; i++) { ctx.fillStyle = `rgba(20,4,2,${r() * .35})`; ctx.fillRect(r() * w, r() * h, 6 + r() * 30, 1); }
  });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 1);
  return t;
}
function buildBase() {
  const g = new THREE.Group(); scene.add(g);
  const add = (geo, mat, y) => { const m = new THREE.Mesh(geo, mat); m.position.y = y; m.castShadow = m.receiveShadow = true; g.add(m); return m; };
  // 懸空版：沒有木座、底盤與支柱，整座儀器懸浮在空中
  // 刻度環外框（含圓潤邊緣與底面厚度）
  add(new THREE.LatheGeometry([[4.3, .02], [4.36, .12], [4.5, .16], [4.66, .12], [4.72, .02], [4.72, -.08], [4.3, -.08], [4.3, .02]].map(q => new THREE.Vector2(q[0], q[1])), 160), mats.brass, 0);
  add(new THREE.RingGeometry(3.08, 4.32, 160, 1).rotateX(Math.PI / 2), mats.brassDark, -.08);
  add(new THREE.CylinderGeometry(3.08, 3.08, .1, 160, 1, true), mats.brass, -.03);
  const studs = new THREE.InstancedMesh(new THREE.SphereGeometry(.045, 12, 8), mats.gold, 72);
  const m4 = new THREE.Matrix4();
  for (let k = 0; k < 72; k++) { const a = k * TAU / 72; m4.makeTranslation(4.6 * Math.cos(a), .155, -4.6 * Math.sin(a)); studs.setMatrixAt(k, m4); }
  g.add(studs);
  // 機芯平台：懸在刻度環下方，中央立柱末端加上垂飾
  add(new THREE.CylinderGeometry(1.15, 1.15, .05, 96), mats.brass, -.62);
  add(new THREE.SphereGeometry(.11, 32, 20), mats.gold, -1.0);
  add(new THREE.ConeGeometry(.07, .26, 24).rotateX(Math.PI), mats.gold, -1.2);
}
function buildBands() {
  // 外圈：三條細銅環以不同角度斜跨整座儀器，環上鑲著銅球，並緩緩迴旋
  refs.cage = [];
  // 每條環：半徑、傾角、方位、高度；最低點仍高於木座日期窗
  [[5.0, 12, 20, .62], [5.15, -10, 110, .78], [5.3, 6, 65, .5]].forEach(([R, tilt, yaw, y], i) => {
    const g = new THREE.Group(); g.position.y = y; g.rotation.y = deg(yaw); scene.add(g);
    const t = new THREE.Group(); t.rotation.x = deg(tilt); g.add(t);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(R, .034, 14, 320).rotateX(Math.PI / 2), mats.gold); ring.castShadow = true; t.add(ring);
    for (let k = 0; k < 10; k++) {
      const a = k * TAU / 10 + i * .3, big = k % 5 === 0;
      const b = new THREE.Mesh(new THREE.SphereGeometry(big ? .14 : .075, 28, 18), mats.gold); b.position.set(R * Math.cos(a), 0, -R * Math.sin(a)); b.castShadow = true; t.add(b);
      if (big) { const c = new THREE.Mesh(new THREE.TorusGeometry(.15, .018, 8, 32), mats.brass); c.position.copy(b.position); c.lookAt(0, 0, 0); t.add(c); }
    }
    refs.cage.push({ g, speed: (i % 2 ? -1 : 1) * (.03 + .015 * i) });
  });
  // 刻度環下方：外露的齒輪組，隨時間咬合轉動
  refs.underGears = [];
  const gb = extrudeGear(gearShape(20, .035, 4), .04).rotateX(Math.PI / 2), gs = extrudeGear(gearShape(12, .035, 3), .04).rotateX(Math.PI / 2);
  for (let k = 0; k < 6; k++) {
    const phi = deg(k * 60 + 15), grp = new THREE.Group(); grp.position.set(3.82 * Math.sin(phi), -.5, 3.82 * Math.cos(phi)); grp.rotation.y = phi; scene.add(grp);
    const big = new THREE.Mesh(gb, mats.brass), small = new THREE.Mesh(gs, mats.gold); small.position.x = .56;
    [big, small].forEach(m => { m.castShadow = true; grp.add(m); });
    const hub = new THREE.Mesh(new THREE.SphereGeometry(.06, 16, 12), mats.gold); hub.position.z = .05; grp.add(hub);
    refs.underGears.push({ big, small });
  }
}
function animateExtras(dt) {
  refs.cage.forEach(c => { c.g.rotation.y += dt * c.speed * (reduced ? 0 : 1); });
  refs.tower.forEach(t => { t.mesh.rotation.y = alpha * t.dir * t.ratio * .6; });
  refs.underGears.forEach(u => {
    u.big.rotation.z = alpha * .8;
    u.small.rotation.z = Math.PI - Math.PI / 12 + (0 - alpha * .8) * 20 / 12;   // 外嚙合：齒數比 20:12
  });
}
function textRot(ctx, x, y, thetaDeg, draw) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(-(thetaDeg + 90) * D2R); draw(); ctx.restore();
}
function gearShape(N, m, spokes) {
  const r = m * N / 2, ra = r + m, rf = r - 1.25 * m, p = TAU / N, s = new THREE.Shape();
  for (let j = 0; j < N; j++) {
    const c = j * p, pts = [[rf, c - .32 * p], [ra, c - .15 * p], [ra, c + .15 * p], [rf, c + .32 * p]];
    pts.forEach(([rr, a], i) => (j === 0 && i === 0 ? s.moveTo : s.lineTo).call(s, rr * Math.cos(a), rr * Math.sin(a)));
  }
  s.closePath();
  if (spokes) {
    const rimIn = rf - 1.5 * m, hub = Math.max(r * .3, m * 2), w = m * .7;
    for (let k = 0; k < spokes; k++) {
      const s0 = TAU * k / spokes, s1 = TAU * (k + 1) / spokes, h = new THREE.Path();
      h.absarc(0, 0, rimIn, s0 + w / rimIn, s1 - w / rimIn, false);
      h.lineTo(hub * Math.cos(s1 - w / hub), hub * Math.sin(s1 - w / hub));
      h.absarc(0, 0, hub, s1 - w / hub, s0 + w / hub, true);
      s.holes.push(h);
    }
  }
  const ax = new THREE.Path(); ax.absarc(0, 0, m * .9, 0, TAU, true); s.holes.push(ax);
  return s;
}
function ringGearShape(Nin, Nout, m) {
  const s = new THREE.Shape(), R = m * Nout / 2, p = TAU / Nout;
  for (let j = 0; j < Nout; j++) {
    const c = j * p;
    [[R - 1.25 * m, c - .32 * p], [R + m, c - .15 * p], [R + m, c + .15 * p], [R - 1.25 * m, c + .32 * p]]
      .forEach(([rr, a], i) => (j === 0 && i === 0 ? s.moveTo : s.lineTo).call(s, rr * Math.cos(a), rr * Math.sin(a)));
  }
  s.closePath();
  const r = m * Nin / 2, q = TAU / Nin, h = new THREE.Path();
  for (let j = 0; j < Nin; j++) {
    const c = j * q;
    [[r + 1.25 * m, c - .32 * q], [r - m, c - .15 * q], [r - m, c + .15 * q], [r + 1.25 * m, c + .32 * q]]
      .forEach(([rr, a], i) => (j === 0 && i === 0 ? h.moveTo : h.lineTo).call(h, rr * Math.cos(a), rr * Math.sin(a)));
  }
  h.closePath(); s.holes.push(h);
  const hr = (r + 1.25 * m + R - 1.25 * m) / 2;
  for (let k = 0; k < 24; k++) { const c = new THREE.Path(), a = k * TAU / 24; c.absarc(hr * Math.cos(a), hr * Math.sin(a), m * .55, 0, TAU, true); s.holes.push(c); }
  return s;
}
function extrudeGear(shape, depth) {
  return new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelThickness: depth * .18, bevelSize: depth * .12, bevelSegments: 2, curveSegments: 10 }).rotateX(-Math.PI / 2);
}
function buildGears() {
  const M = .068, G = refs.gears, Y = -.585;
  const mk = (geo, mat, x, z, y) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; scene.add(m); return m; };
  G.ring = mk(extrudeGear(ringGearShape(60, 70, M), .07), mats.bronze, 0, 0, Y);
  G.planets = [];
  const pg = extrudeGear(gearShape(18, M, 4), .08);
  for (let k = 0; k < 6; k++) {
    const psi = k * 60 * D2R, d = (24 + 18) * M / 2;
    G.planets.push({ mesh: mk(pg, mats.brass, d * Math.cos(psi), -d * Math.sin(psi), Y + .005), psi });
    const pin = mk(new THREE.CylinderGeometry(.035, .035, .16, 16), mats.ruby, d * Math.cos(psi), -d * Math.sin(psi), Y + .08);
    pin.castShadow = false;
  }
  G.sun = mk(extrudeGear(gearShape(24, M, 5), .09), mats.gold, 0, 0, Y + .01);
  // 陀飛輪（位於太陽輪上方，框架一分鐘一圈）
  const tb = new THREE.Group(); tb.position.y = -.38; scene.add(tb);
  G.cage = new THREE.Group(); tb.add(G.cage);
  const cageRing = new THREE.Mesh(new THREE.TorusGeometry(.56, .028, 12, 72).rotateX(Math.PI / 2), mats.gold); cageRing.castShadow = true; G.cage.add(cageRing);
  for (let k = 0; k < 3; k++) {
    const a = k * TAU / 3;
    const br = new THREE.Mesh(new THREE.BoxGeometry(.5, .03, .07), mats.brass); br.position.set(.3 * Math.cos(a), .02, -.3 * Math.sin(a)); br.rotation.y = a; br.castShadow = true; G.cage.add(br);
    const jw = new THREE.Mesh(new THREE.SphereGeometry(.035, 16, 12), mats.ruby); jw.position.set(.5 * Math.cos(a), .05, -.5 * Math.sin(a)); G.cage.add(jw);
  }
  G.esc = new THREE.Mesh(extrudeGear(gearShape(15, .026, 0), .02), mats.steel); G.esc.position.set(.36 * Math.cos(1), .045, -.36 * Math.sin(1)); G.cage.add(G.esc);
  G.bal = new THREE.Group(); G.bal.position.y = .08; tb.add(G.bal);
  G.bal.add(new THREE.Mesh(new THREE.TorusGeometry(.32, .02, 10, 64).rotateX(Math.PI / 2), mats.gold));
  [0, Math.PI / 2].forEach(a => { const sp = new THREE.Mesh(new THREE.BoxGeometry(.64, .012, .025), mats.gold); sp.rotation.y = a; G.bal.add(sp); });
  for (let k = 0; k < 8; k++) { const sc = new THREE.Mesh(new THREE.SphereGeometry(.022, 10, 8), mats.steel); sc.position.set(.345 * Math.cos(k * TAU / 8), 0, -.345 * Math.sin(k * TAU / 8)); G.bal.add(sc); }
  const sp = []; for (let t = 0; t < 7 * TAU; t += .2) { const r = .07 + .028 * t / TAU; sp.push(new THREE.Vector3(r * Math.cos(t), .1, -r * Math.sin(t))); }
  tb.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(sp), 300, .004, 5), mats.steel));
}
function faceGroup(phiDeg) {
  const g = new THREE.Group(), p = deg(phiDeg);
  g.position.set(FACE_A * Math.sin(p), FACE_Y, FACE_A * Math.cos(p)); g.rotation.y = p; scene.add(g);
  return g;
}
function drumTex(cells, arc, w, digit) {
  const cp = 160, H = Math.max(64, Math.round(cp * w / arc));
  return canvasTex(cells.length * cp, H, (ctx, W) => {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#d9ccad'); g.addColorStop(.5, '#f1e8d2'); g.addColorStop(1, '#d9ccad');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const size = Math.min(cp * .6, H * .8);
    ctx.font = digit ? `700 ${size * 1.15}px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif` : `900 ${size}px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    cells.forEach((t, i) => {
      ctx.fillStyle = 'rgba(70,40,15,.3)'; ctx.fillRect(i * cp, 0, 2, H);
      ctx.save(); ctx.translate((i + .5) * cp, H / 2); ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = '#2a170a'; ctx.fillText(t, 0, digit ? size * .06 : size * .04); ctx.restore();
    });
  });
}
function addDrum(parent, x, cells, w, arc = .3, digit = false) {   // 圓筒半徑 = 格數 × 格高 ÷ 2π，需小於約 0.46 才不會露出窗框外
  const N = cells.length, r = N * arc / TAU;
  const side = new THREE.MeshStandardMaterial({ map: drumTex(cells, arc, w, digit), roughness: .5, metalness: 0 });
  const geo = new THREE.CylinderGeometry(r, r, w, Math.max(48, N * 8), 1, false).rotateZ(-Math.PI / 2);
  const m = new THREE.Mesh(geo, [side, mats.brassDark, mats.brassDark]);
  m.position.set(x, 0, .2 - r); parent.add(m);
  const d = { mesh: m, N, a: 0, target: 0, idx: -1 }; drums.push(d);
  return d;
}
function setDrum(d, i) {
  if (i < 0 || d.idx === i) return;
  d.idx = i;
  const want = -TAU * (i + .5) / d.N;
  d.target = d.a + wrapPi(want - d.a);
}
function roundRect(w, h, r) {
  const s = new THREE.Shape(), x = -w / 2, y = -h / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function rectHole(x0, x1, y0, y1) {
  const h = new THREE.Path(); h.moveTo(x0, y0); h.lineTo(x1, y0); h.lineTo(x1, y1); h.lineTo(x0, y1); h.closePath(); return h;
}
function makePlaque(parent, w, h, holes, labels) {
  const s = roundRect(w, h, .05); holes.forEach(hp => s.holes.push(hp));
  const geo = new THREE.ExtrudeGeometry(s, { depth: .025, bevelEnabled: true, bevelThickness: .008, bevelSize: .008, bevelSegments: 2, curveSegments: 28 });
  const m = new THREE.Mesh(geo, mats.brass); m.position.z = .22; m.castShadow = m.receiveShadow = true;
  m.userData.key = 'windows'; parent.add(m); refs.pickables.push(m);
  const wall = (W, H, x, y) => { const b = new THREE.Mesh(new THREE.BoxGeometry(W, H, .22), mats.brassDark); b.position.set(x, y, .11); parent.add(b); };
  wall(w, .025, 0, h / 2 - .0125); wall(w, .025, 0, -h / 2 + .0125); wall(.025, h, -w / 2 + .0125, 0); wall(.025, h, w / 2 - .0125, 0);
  const W = 1024, H = Math.round(1024 * h / w);
  const t = canvasTex(W, H, ctx => {
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    labels.forEach(l => {
      ctx.font = `900 ${Math.round(l.size * W / w)}px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif`;
      const x = (l.x / w + .5) * W, y = (.5 - l.y / h) * H;
      ctx.fillStyle = 'rgba(255,225,170,.35)'; ctx.fillText(l.text, x + 1.5, y + 1.5);   // 刻字的亮邊
      ctx.fillStyle = '#24130a'; ctx.fillText(l.text, x, y);
    });
  });
  const pl = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ map: t, transparent: true, roughness: .6, metalness: .1, depthWrite: false }));
  pl.position.z = .22 + .025 + .0095; parent.add(pl);
}
function sizeDust() {
  const r = dust.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
  dust.width = Math.round(r.width * dpr); dust.height = Math.round(r.height * dpr);
  dctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  stars = Array.from({ length: Math.round(r.width * r.height / 4800) }, () => ({ x: Math.random() * r.width, y: Math.random() * r.height, r: Math.random() * 1.2 + .3, a: Math.random() * TAU, s: Math.random() * .6 + .2, gold: Math.random() < .3 }));
}
function drawDust(dt, moving) {
  const w = dust.clientWidth, h = dust.clientHeight;
  dctx.clearRect(0, 0, w, h);
  stars.forEach(s => {
    if (moving) { s.x += s.s * 4 * dt; s.y -= s.s * 2.2 * dt; s.a += dt * s.s * 1.6; if (s.x > w) s.x = 0; if (s.y < 0) s.y = h; }
    const al = .25 + .35 * (.5 + .5 * Math.sin(s.a));
    dctx.fillStyle = s.gold ? `rgba(240,210,140,${al})` : `rgba(200,215,240,${al})`;
    dctx.beginPath(); dctx.arc(s.x, s.y, s.r, 0, TAU); dctx.fill();
  });
}
function applyGears() {
  const G = refs.gears;
  G.sun.rotation.y = alpha;
  let p0 = 0;
  G.planets.forEach((p, k) => {
    const th = p.psi + Math.PI - Math.PI / 18 + (p.psi - alpha) * 24 / 18;
    if (k === 0) p0 = th;
    p.mesh.rotation.y = th;
  });
  const v = (0 - p0) * 18 / TAU;
  G.ring.rotation.y = -(TAU / 60) * (v - .5);
  G.cage.rotation.y = cageA;
  G.bal.rotation.y = Math.sin(clock * TAU * 1.25) * 3.6;
  const s5 = clock * 5, fr = s5 - Math.floor(s5);
  G.esc.rotation.y = (Math.floor(s5) + Math.min(1, fr * 4)) * TAU / 15;
}

function buildEnvScene() {
  const env = new THREE.Scene();
  env.add(new THREE.Mesh(new THREE.SphereGeometry(20, 32, 16), new THREE.MeshBasicMaterial({ color: 0x141a28, side: THREE.BackSide })));
  const floor = new THREE.Mesh(new THREE.CircleGeometry(20, 32).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x2a1c10 })); floor.position.y = -5; env.add(floor);
  const panel = (w, h, col, x, y, z) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: col, side: THREE.DoubleSide })); m.position.set(x, y, z); m.lookAt(0, 0, 0); env.add(m); };
  panel(16, 12, new THREE.Color(5.2, 4.9, 4.4), 0, 13, 1); panel(8, 10, new THREE.Color(4.2, 3.7, 3.1), -11, 5, 7);
  panel(6, 12, new THREE.Color(2.3, 2.6, 3.2), 11, 4, -4); panel(14, 4, new THREE.Color(1.9, 1.7, 1.4), 0, 1, 13); panel(10, 3, new THREE.Color(1.6, 1.3, .9), 0, 3, -13);
  return env;
}

function buildScene() {
  const SMALL = window.innerWidth < 700;   // 手機：降低解析度與陰影品質，維持流暢
  renderer.setPixelRatio(Math.min(SMALL ? Math.min(1.5, Q.pr) : Q.pr, window.devicePixelRatio || 1));
  renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = .98;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.setClearColor(0, 0);
  glBox.appendChild(renderer.domElement);
  scene = new THREE.Scene();
  scene.environment = new THREE.PMREMGenerator(renderer).fromScene(buildEnvScene(), .03).texture;
  camera = new THREE.PerspectiveCamera(30, 1, .1, 100);
  controls = new THREE.OrbitControls(camera, renderer.domElement);
  renderer.domElement.style.touchAction = 'pan-y';   // 手機上下滑動可捲動頁面，左右滑動旋轉視角
  Object.assign(controls, { enableDamping: true, dampingFactor: .08, enablePan: false, rotateSpeed: .55, minPolarAngle: deg(10), maxPolarAngle: deg(80) });
  controls.target.set(0, .55, 0);
  const key = refs.key = new THREE.DirectionalLight(0xfff4e2, 1.1); key.position.set(-5, 9, 6); key.castShadow = Q.shadow > 0; key.shadow.mapSize.set(Q.shadow || 1024, Q.shadow || 1024);
  renderer.shadowMap.autoUpdate = false;   // 陰影只在畫面重繪時更新，不必每一幀都重算
  Object.assign(key.shadow.camera, { left: -7, right: 7, top: 7, bottom: -7, near: 1, far: 34 }); key.shadow.bias = -.0004; key.shadow.normalBias = .02; scene.add(key);
  const rim = new THREE.DirectionalLight(0x8fb0ff, .45); rim.position.set(6, 3, -7); scene.add(rim);
  scene.add(new THREE.HemisphereLight(0x9fb6e8, 0x2a1a08, .3));
  const sunLight = new THREE.PointLight(0xffd9a0, 2.4, 12, 1.2); sunLight.position.set(0, PLANE_Y, 0); scene.add(sunLight);
  const brushed = brushedTex(5, 8), brushedWide = brushedTex(9, 2), hammer = hammeredTex(), wood = woodTex();
  const brassMat = (color, rough = .6, rmap = brushed, coat = .15) => new THREE.MeshPhysicalMaterial({ color, metalness: 1, roughness: rough * 2, roughnessMap: rmap, bumpMap: rmap, bumpScale: .0012, clearcoat: coat, clearcoatRoughness: .1 });
  mats = {
    // 參考圖的色調：拋光古金，亮面金黃、暗面深棕，對比強
    brass: brassMat(0x864109, .42, brushed, .45), brassDark: brassMat(0x4f2406, .52, brushed, .3), band: brassMat(0x8a4510, .4, brushedWide, .45),
    gold: new THREE.MeshPhysicalMaterial({ color: 0xb0661a, metalness: 1, roughness: .16, clearcoat: .6, clearcoatRoughness: .06 }),
    bronze: brassMat(0x3a1a06, .5, brushed, .35), copper: brassMat(0xa13f1e, .45),
    steel: new THREE.MeshStandardMaterial({ color: 0xe2e6ec, metalness: 1, roughness: .16 }),
    ruby: new THREE.MeshPhysicalMaterial({ color: 0xa3122a, metalness: 0, roughness: .05, clearcoat: 1, emissive: 0x3a0008 }),
    hammered: new THREE.MeshPhysicalMaterial({ color: 0x7a3d0c, metalness: 1, roughness: .38, bumpMap: hammer, bumpScale: .035, clearcoat: .5, clearcoatRoughness: .2 }),
    wood: brassMat(0x2c1404, .5, brushed, .4),   // 底座改為深色古銅，與參考圖的金屬機座一致
  };
  tex.glow = canvasTex(256, 256, (ctx, w) => { const g = ctx.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2); g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(.25, 'rgba(255,255,255,.35)'); g.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, w); });
  buildBase(); buildDial(); buildGears(); buildCore(); buildBands(); buildPlanets();
  resize();
}

/* ── 盤面：黃道星座環、黃經刻度與節氣、地球日曆環 ── */
function zodiacPainter(metal) {
  return (ctx, W) => {
    const c = W / 2, s = c / 4.32, P = (r, t) => [c + r * s * Math.cos(t * D2R), c - r * s * Math.sin(t * D2R)];
    const ink = metal ? '#fff' : '#e4b47c';
    if (metal) { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, W); }
    else {
      const g = ctx.createRadialGradient(c, c, 3 * s, c, c, 4.32 * s); g.addColorStop(0, '#0f2c5c'); g.addColorStop(1, '#071a3c'); ctx.fillStyle = g; ctx.fillRect(0, 0, W, W);
      ZODIAC.forEach((z, i) => {               // 星座扇區交錯底色
        const a0 = z[2], a1 = z[3] < z[2] ? z[3] + 360 : z[3];
        ctx.fillStyle = i % 2 ? 'rgba(40,74,130,.55)' : 'rgba(18,40,84,.55)';
        ctx.beginPath(); ctx.arc(c, c, 4.3 * s, -a1 * D2R, -a0 * D2R); ctx.arc(c, c, 3.66 * s, -a0 * D2R, -a1 * D2R, true); ctx.fill();
      });
    }
    ctx.strokeStyle = ink; ctx.fillStyle = ink; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    [3.1, 3.62, 3.66, 4.3].forEach((r, i) => { ctx.lineWidth = i === 1 || i === 2 ? 2 : 4; ctx.beginPath(); ctx.arc(c, c, r * s, 0, TAU); ctx.stroke(); });
    ZODIAC.forEach(z => {
      const [x0, y0] = P(3.66, z[2]), [x1, y1] = P(4.3, z[2]); ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      const span = norm(z[3] - z[2]), mid = z[2] + span / 2, [x, y] = P(4.03, mid), [x2, y2] = P(3.8, mid);
      textRot(ctx, x, y, mid, () => { ctx.font = `700 ${span < 10 ? 34 : 46}px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif`; ctx.fillText(z[0], 0, 0); });
      if (span > 10) textRot(ctx, x2, y2, mid, () => { ctx.font = '600 26px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif'; ctx.fillText(z[1], 0, 0); });
    });
    for (let l = 0; l < 360; l += 1) {          // 黃經刻度
      const major = l % 10 === 0, mid5 = l % 5 === 0, [x0, y0] = P(major ? 3.42 : mid5 ? 3.5 : 3.55, l), [x1, y1] = P(3.62, l);
      ctx.lineWidth = major ? 3 : 1.5; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
      if (major && l % 30 === 0) { const [x, y] = P(3.32, l); textRot(ctx, x, y, l, () => { ctx.font = '600 24px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif'; ctx.fillText(l + '°', 0, 0); }); }
    }
    for (let i = 0; i < 24; i++) { const [x, y] = P(3.19, i * 15); textRot(ctx, x, y, i * 15, () => { ctx.font = '600 22px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif'; ctx.fillText(TERM[i], 0, 0); }); }
  };
}
function calendarPainter(year, metal) {
  return (ctx, W) => {
    const c = W / 2, s = c / 3.05, P = (r, t) => [c + r * s * Math.cos(t * D2R), c - r * s * Math.sin(t * D2R)];
    ctx.fillStyle = metal ? '#fff' : '#a8703f'; ctx.fillRect(0, 0, W, W);
    if (!metal) { ctx.globalAlpha = .12; ctx.strokeStyle = '#fff'; for (let r = 2.5; r < 3.05; r += .012) { ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(c, c, r * s, 0, TAU); ctx.stroke(); } ctx.globalAlpha = 1; }
    const ink = metal ? '#000' : '#1e0f04'; ctx.strokeStyle = ink; ctx.fillStyle = ink; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    // 每一天的刻度放在當天正午地球的日心黃經上
    const lonAt = (m, d) => A.lonOf(A.helio('earth', jdOf(year, m, d) + .5 - TZ));
    for (let m = 1; m <= 12; m++) {
      const n = dim(year, m);
      for (let d = 1; d <= n; d++) {
        const l = lonAt(m, d) - .49, [x0, y0] = P(d === 1 ? 2.52 : d % 5 === 0 ? 2.9 : 2.97, l), [x1, y1] = P(3.05, l);
        ctx.lineWidth = d === 1 ? 4 : 1.6; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
        if (d % 5 === 0 && d < 30) { const [x, y] = P(2.83, l + .5); textRot(ctx, x, y, l, () => { ctx.font = '600 20px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif'; ctx.fillText(d, 0, 0); }); }
      }
      const mid = lonAt(m, 16), [x, y] = P(2.66, mid);
      textRot(ctx, x, y, mid, () => { ctx.font = '700 34px system-ui, -apple-system, "Segoe UI", "PingFang TC", "Microsoft JhengHei", "Noto Sans TC", sans-serif'; ctx.fillText(m + '月', 0, 0); });
    }
  };
}
function paintInto(t, painter) { const c = t.userData.canvas; painter(c.getContext('2d'), c.width, c.height); t.needsUpdate = true; }
function buildDial() {
  tex.dial = canvasTex(2048, 2048, zodiacPainter(false)); tex.dialMetal = canvasTex(2048, 2048, zodiacPainter(true), false);
  const dial = new THREE.Mesh(new THREE.RingGeometry(3.08, 4.32, 180, 1).rotateX(-Math.PI / 2),
    new THREE.MeshPhysicalMaterial({ map: tex.dial, metalnessMap: tex.dialMetal, metalness: 1, roughness: .32, clearcoat: .8, clearcoatRoughness: .25 }));
  dial.receiveShadow = true; scene.add(dial);
  [[3.08, .03], [4.31, .03], [2.48, .035]].forEach(([r, tube]) => { const t = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 12, 200).rotateX(Math.PI / 2), mats.gold); t.position.y = .01; t.castShadow = t.receiveShadow = true; scene.add(t); });
  refs.calYear = null;
  tex.cal = canvasTex(1536, 1536, () => {}); tex.calMetal = canvasTex(1536, 1536, () => {}, false);
  const cal = new THREE.Mesh(new THREE.RingGeometry(2.52, 3.05, 160, 1).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: tex.cal, metalnessMap: tex.calMetal, metalness: 1, roughness: .46 }));
  cal.position.y = .045; cal.receiveShadow = true; scene.add(cal);
  const calUnder = new THREE.Mesh(new THREE.RingGeometry(2.52, 3.05, 160, 1).rotateX(Math.PI / 2), mats.brassDark); calUnder.position.y = -.005; scene.add(calUnder);
  const hiMat = o => new THREE.MeshBasicMaterial({ color: 0xffd98a, transparent: true, opacity: o, blending: THREE.AdditiveBlending, depthWrite: false });
  refs.hover = new THREE.Mesh(new THREE.RingGeometry(1, 2, 16, 1, 0, .2).rotateX(-Math.PI / 2), hiMat(.14)); refs.hover.visible = false; scene.add(refs.hover);
  // 指針：指向地球的日心黃經，可讀出日期，以及午夜時高掛南方的星座
  const sh = new THREE.Shape();
  sh.moveTo(-.75, -.05); sh.lineTo(-.45, -.035); sh.lineTo(3.95, -.022); sh.lineTo(4.05, -.075); sh.lineTo(4.3, 0); sh.lineTo(4.05, .075); sh.lineTo(3.95, .022); sh.lineTo(-.45, .035); sh.lineTo(-.75, .05); sh.closePath();
  refs.pointer = new THREE.Group(); refs.pointer.position.y = .1; scene.add(refs.pointer);
  refs.needleMat = mats.gold.clone();
  const needle = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: .025, bevelEnabled: true, bevelThickness: .008, bevelSize: .008, bevelSegments: 2 }).rotateX(-Math.PI / 2), refs.needleMat);
  needle.castShadow = true; needle.userData.key = 'earth'; refs.pointer.add(needle); refs.pickables.push(needle);
}
function repaintCalendar(year) {
  if (!renderer || refs.calYear === year) return;
  refs.calYear = year; paintInto(tex.cal, calendarPainter(year, false)); paintInto(tex.calMetal, calendarPainter(year, true));
}

/* ── 中央立柱與太陽 ── */
function buildCore() {
  const col = new THREE.Mesh(new THREE.CylinderGeometry(.05, .07, PLANE_Y + .95, 24), mats.brass); col.position.y = (PLANE_Y - .95) / 2; col.castShadow = true; scene.add(col);
  [-.2, .35, .8].forEach(y => { const c = new THREE.Mesh(new THREE.TorusGeometry(.085, .028, 12, 32).rotateX(Math.PI / 2), mats.gold); c.position.y = y; scene.add(c); });
  // 中央機械塔：層層堆疊、交替反轉的齒輪與金環（參考圖中央的塔狀機構）
  refs.tower = [];
  [[30, .042, .14, mats.brass], [24, .036, .4, mats.gold], [20, .032, .64, mats.brass], [14, .03, .86, mats.gold]].forEach(([N, m, y, mat], i) => {
    const g = new THREE.Mesh(extrudeGear(gearShape(N, m, i % 2 ? 4 : 5), .045), mat); g.position.y = y; g.castShadow = g.receiveShadow = true; scene.add(g);
    const r = m * N / 2 + m * 1.6, ring = new THREE.Mesh(new THREE.TorusGeometry(r, .016, 10, 96).rotateX(Math.PI / 2), mats.gold); ring.position.y = y + .11; scene.add(ring);
    for (let k = 0; k < 3; k++) { const a = k * TAU / 3 + i, post = new THREE.Mesh(new THREE.CylinderGeometry(.012, .012, .11, 8), mats.gold); post.position.set(r * Math.cos(a), y + .055, -r * Math.sin(a)); scene.add(post); }
    refs.tower.push({ mesh: g, ring, dir: i % 2 ? -1 : 1, ratio: 30 / N });
  });
  const sunTex = canvasTex(512, 256, (ctx, w, h) => { const g = ctx.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#e0a03a'); g.addColorStop(.5, '#ffd27a'); g.addColorStop(1, '#d08a2a'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const r = rnd(3); for (let i = 0; i < 900; i++) { ctx.fillStyle = `rgba(150,80,10,${r() * .25})`; ctx.beginPath(); ctx.arc(r() * w, r() * h, r() * 4 + 1, 0, TAU); ctx.fill(); } });
  refs.sun = new THREE.Mesh(new THREE.SphereGeometry(.36, 64, 40), new THREE.MeshPhysicalMaterial({ map: sunTex, emissive: 0xff8a1a, emissiveIntensity: .38, metalness: .85, roughness: .2, clearcoat: .7, clearcoatRoughness: .05 }));
  refs.sun.position.y = PLANE_Y; refs.sun.userData.key = 'sun'; scene.add(refs.sun); refs.pickables.push(refs.sun);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex.glow, color: 0xffc06a, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: .7 }));
  halo.scale.set(2, 2, 1); halo.position.y = PLANE_Y; scene.add(halo);
}

/* ── 行星：真實軌道（壓縮半徑）、自轉、懸臂；從地球射向星座環的視線 ── */
function planetTex(kind) {
  return canvasTex(1024, 512, (ctx, w, h) => {
    const r = rnd(kind.length * 31 + 7);
    const bands = (cols) => { for (let y = 0; y < h; y += 4) { const k = Math.floor((y / h) * cols.length + Math.sin(y * .05) * .4); ctx.fillStyle = cols[clamp(k, 0, cols.length - 1)]; ctx.fillRect(0, y, w, 4); } };
    if (kind === 'mercury') { ctx.fillStyle = '#9a948b'; ctx.fillRect(0, 0, w, h); for (let i = 0; i < 260; i++) { ctx.fillStyle = `rgba(${r() < .5 ? '60,58,55' : '200,195,185'},${r() * .35})`; ctx.beginPath(); ctx.arc(r() * w, r() * h, r() * 16 + 2, 0, TAU); ctx.fill(); } }
    else if (kind === 'venus') { ctx.fillStyle = '#e8d29a'; ctx.fillRect(0, 0, w, h); for (let i = 0; i < 120; i++) { ctx.strokeStyle = `rgba(${r() < .5 ? '255,245,215' : '190,150,80'},.3)`; ctx.lineWidth = 6 + r() * 14; ctx.beginPath(); const y = r() * h; ctx.moveTo(0, y); ctx.bezierCurveTo(w * .3, y + r() * 40 - 20, w * .6, y + r() * 40 - 20, w, y); ctx.stroke(); } }
    else if (kind === 'mars') { ctx.fillStyle = '#c45a32'; ctx.fillRect(0, 0, w, h); for (let i = 0; i < 160; i++) { ctx.fillStyle = `rgba(90,35,20,${r() * .4})`; ctx.beginPath(); ctx.ellipse(r() * w, h * (.3 + r() * .4), r() * 60 + 10, r() * 20 + 6, r() * 3, 0, TAU); ctx.fill(); } ctx.fillStyle = 'rgba(255,250,240,.85)'; ctx.fillRect(0, 0, w, 22); ctx.fillRect(0, h - 16, w, 16); }
    else if (kind === 'jupiter') { bands(['#efe0c2', '#c8986a', '#f2e6cc', '#b07a52', '#efe0c2', '#c99a6c', '#f0e2c6', '#a87250', '#efe0c2']); ctx.fillStyle = '#c4553a'; ctx.beginPath(); ctx.ellipse(w * .6, h * .64, 34, 18, 0, 0, TAU); ctx.fill(); }
    else if (kind === 'saturn') bands(['#efe0b4', '#d9bf86', '#f2e6c0', '#cfae74', '#efe0b4', '#d6ba80', '#efe0b4']);
    else if (kind === 'lapis') {
      ctx.fillStyle = '#1c3f8f'; ctx.fillRect(0, 0, w, h);
      for (let i = 0; i < 700; i++) { ctx.fillStyle = `hsla(${215 + r() * 15},${55 + r() * 25}%,${18 + r() * 30}%,.35)`; ctx.beginPath(); ctx.ellipse(r() * w, r() * h, r() * 40 + 6, r() * 18 + 4, r() * 3, 0, TAU); ctx.fill(); }
      for (let i = 0; i < 520; i++) { ctx.fillStyle = `rgba(240,205,110,${.5 + r() * .5})`; ctx.beginPath(); ctx.arc(r() * w, r() * h, r() * 2.2 + .6, 0, TAU); ctx.fill(); }
    } else { ctx.fillStyle = '#c9ccd3'; ctx.fillRect(0, 0, w, h); for (let i = 0; i < 160; i++) { ctx.fillStyle = `rgba(70,75,85,${.15 + r() * .25})`; ctx.beginPath(); ctx.arc(r() * w, r() * h, r() * 18 + 3, 0, TAU); ctx.fill(); } }
  });
}
function buildPlanets() {
  refs.orbitGroup = new THREE.Group(); scene.add(refs.orbitGroup);
  ORDER.forEach(k => {
    const B = BODY[k], b = refs.bodies[k] = { key: k };
    b.mat = k === 'earth' ? new THREE.MeshPhysicalMaterial({ map: planetTex('lapis'), metalness: .15, roughness: .22, clearcoat: 1, clearcoatRoughness: .08 })
      : new THREE.MeshPhysicalMaterial({ map: planetTex(k), metalness: .35, roughness: .28, clearcoat: 1, clearcoatRoughness: .08 });
    b.mesh = new THREE.Mesh(new THREE.SphereGeometry(B.size, 48, 32), b.mat); b.mesh.castShadow = true; b.mesh.userData.key = k;
    scene.add(b.mesh); refs.pickables.push(b.mesh);
    b.armMat = mats.brassDark;
    b.arm = new THREE.Mesh(new THREE.CylinderGeometry(.012, .016, 1, 8), b.armMat); b.arm.castShadow = true; scene.add(b.arm);
    b.cup = new THREE.Mesh(new THREE.CylinderGeometry(B.size * .4, B.size * .28, B.size * .45, 16), mats.gold); scene.add(b.cup);
    b.hoopMat = mats.brass.clone();
    if (k === 'saturn') {
      const ringTex = canvasTex(512, 32, (ctx, w, h) => { const g = ctx.createLinearGradient(0, 0, w, 0); g.addColorStop(0, 'rgba(220,200,150,.0)'); g.addColorStop(.1, 'rgba(220,200,150,.85)'); g.addColorStop(.55, 'rgba(235,215,165,.95)'); g.addColorStop(.6, 'rgba(60,50,30,.3)'); g.addColorStop(.68, 'rgba(210,190,140,.85)'); g.addColorStop(1, 'rgba(200,180,130,.2)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); });
      const rg = new THREE.RingGeometry(B.size * 1.3, B.size * 2.2, 96, 1); const uv = rg.attributes.uv, pos = rg.attributes.position;
      for (let i = 0; i < uv.count; i++) { const r = Math.hypot(pos.getX(i), pos.getY(i)); uv.setXY(i, (r - B.size * 1.3) / (B.size * .9), .5); }
      b.ring = new THREE.Mesh(rg, new THREE.MeshStandardMaterial({ map: ringTex, transparent: true, side: THREE.DoubleSide, roughness: .6, metalness: .2, depthWrite: false }));
      const pole = A.eqToEcl(40.59, 83.54, 23.4393), n = eclDir(pole.lon, pole.lat);
      b.ring.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), n); scene.add(b.ring);
    }
    if (k === 'earth') {
      const pole = eclDir(90, 90 - 23.4393);
      b.tilt = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), pole);
      b.pin = new THREE.Mesh(new THREE.SphereGeometry(.022, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffd98a })); scene.add(b.pin);
      b.moonOrbit = new THREE.Mesh(new THREE.TorusGeometry(.32, .004, 6, 96).rotateX(Math.PI / 2), mats.steel); scene.add(b.moonOrbit);
      b.moon = new THREE.Mesh(new THREE.SphereGeometry(.055, 32, 20), new THREE.MeshStandardMaterial({ map: planetTex('moon'), metalness: .6, roughness: .4 }));
      b.moon.userData.key = 'moon'; b.moon.castShadow = true; scene.add(b.moon); refs.pickables.push(b.moon);
    }
  });
  // 視線光束與星座環上的標記珠
  [...A.PLANETS, 'moon', 'sun'].forEach(k => {
    const col = BODY[k].hex, bd = refs.beads[k] = {};
    bd.beamMat = new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: .5, blending: THREE.AdditiveBlending, depthWrite: false });
    bd.beam = new THREE.Mesh(new THREE.CylinderGeometry(.012, .012, 1, 8, 1, true), bd.beamMat); scene.add(bd.beam);
    bd.bead = new THREE.Mesh(new THREE.SphereGeometry(.06, 20, 14), new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: .35, metalness: .4, roughness: .3 }));
    bd.bead.userData.key = k; scene.add(bd.bead);
    bd.glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex.glow, color: col, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: .55 }));
    bd.glow.scale.set(.42, .42, 1); scene.add(bd.glow);
    if (A.PLANETS.includes(k)) {                 // 過去 120 天的視位置軌跡：往內縮的螺旋，逆行時會打結
      const n = 60, g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3));
      const c = new Float32Array(n * 3), cc = new THREE.Color(col);
      for (let i = 0; i < n; i++) { const f = Math.pow(1 - i / n, 1.3); c.set([cc.r * f, cc.g * f, cc.b * f], i * 3); }
      g.setAttribute('color', new THREE.BufferAttribute(c, 3));
      bd.trail = new THREE.Line(g, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      bd.trail.frustumCulled = false; scene.add(bd.trail); bd.trailT = null;
    }
  });
}
function buildOrbits(jdUT) {
  const decade = Math.round((jdUT - 2451545) / 3652.5);
  if (refs.orbitDecade === decade) return; refs.orbitDecade = decade;
  refs.orbitGroup.clear();
  ORDER.forEach(k => {
    const pts = A.orbitPath(k, jdUT, 240).map(toScene);
    const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, true), 480, .011, 8, true), refs.bodies[k].hoopMat);
    tube.castShadow = true; refs.orbitGroup.add(tube);
  });
}
const UP = typeof THREE !== 'undefined' ? new THREE.Vector3(0, 1, 0) : null;
function segment(mesh, a, b) {
  const d = b.clone().sub(a), L = d.length();
  mesh.position.copy(a).addScaledVector(d, .5); mesh.scale.set(1, L, 1); mesh.quaternion.setFromUnitVectors(UP, d.divideScalar(L || 1));
}
const ringPoint = (lon, r = 3.98, y = .07) => new THREE.Vector3(r * Math.cos(deg(lon)), y, -r * Math.sin(deg(lon)));
let spin = 0;
function applySnapshot(st, dt) {
  buildOrbits(st.jd);
  const P = {};
  ORDER.forEach(k => {
    const b = refs.bodies[k], p = P[k] = toScene(st.helio[k]);
    b.mesh.position.copy(p);
    const from = new THREE.Vector3(0, p.y, 0), dir = p.clone().sub(from).setY(0).normalize();
    segment(b.arm, from.clone().addScaledVector(dir, .34), p.clone().addScaledVector(dir, -BODY[k].size * .6));
    b.cup.position.set(p.x, p.y - BODY[k].size * .95, p.z);
    if (b.ring) b.ring.position.copy(p);
    if (k === 'earth') {
      b.mesh.quaternion.copy(b.tilt).multiply(new THREE.Quaternion().setFromAxisAngle(UP, deg(st.gmst)));
      // 觀測地標記：地球表面上台灣（或所選地點）的位置
      const lst = deg(st.gmst + loc.lon), la = deg(loc.lat), e = deg(23.4393);
      const xq = Math.cos(la) * Math.cos(lst), yq = Math.cos(la) * Math.sin(lst), zq = Math.sin(la);
      const ye = yq * Math.cos(e) + zq * Math.sin(e), ze = -yq * Math.sin(e) + zq * Math.cos(e);
      b.pin.position.copy(p).add(new THREE.Vector3(xq, ze, -ye).multiplyScalar(BODY.earth.size * 1.05));
      const m = st.geo.moon; b.moon.position.copy(p).add(eclDir(m.lon, m.lat * 2).multiplyScalar(.32));
      b.moonOrbit.position.copy(p);
    } else b.mesh.rotation.y += dt * (reduced ? 0 : .4);
  });
  refs.sun.rotation.y += dt * (reduced ? 0 : .12);
  refs.pointer.rotation.y = deg(A.lonOf(st.helio.earth));
  // 視線：地球 → 星座環上的視位置
  const E = P.earth;
  [...A.PLANETS, 'moon', 'sun'].forEach(k => {
    const bd = refs.beads[k], lon = st.geo[k].lon, q = ringPoint(lon, k === 'moon' ? 4.12 : k === 'sun' ? 3.86 : 3.98);
    bd.bead.position.copy(q); bd.glow.position.copy(q); segment(bd.beam, E, q);
    if (bd.trail && (bd.trailT === null || Math.abs(st.T - bd.trailT) > .2)) {
      bd.trailT = st.T;
      const arr = bd.trail.geometry.attributes.position;
      for (let i = 0; i < arr.count; i++) { const g = A.geoPlanet(k, st.jd - i * 2); const v = ringPoint(g.lon, 3.98 - i * .006, .055); arr.setXYZ(i, v.x, v.y, v.z); }
      arr.needsUpdate = true;
    }
  });
}

/* ── 上鍊鑰匙：逐時推進 ── */
function buildCrank() {
  const a = deg(-28), g = new THREE.Group(); g.position.set(4.12 * Math.cos(a), -1.42, -4.12 * Math.sin(a)); g.rotation.y = a; scene.add(g);
  const iron = new THREE.MeshStandardMaterial({ color: 0x2e2a28, metalness: .9, roughness: .38, emissive: 0 });
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(.2, .2, .04, 32).rotateZ(Math.PI / 2), mats.brass); plate.position.x = .02; g.add(plate);
  refs.crankSpin = new THREE.Group(); g.add(refs.crankSpin);
  const add = (geo, x) => { const m = new THREE.Mesh(geo, iron); m.position.x = x; refs.crankSpin.add(m); return m; };
  add(new THREE.CylinderGeometry(.04, .04, .5, 16).rotateZ(Math.PI / 2), .27); add(new THREE.CylinderGeometry(.07, .07, .06, 20).rotateZ(Math.PI / 2), .45);
  add(new THREE.TorusGeometry(.17, .04, 14, 40), .66).castShadow = true;
  const hit = new THREE.Mesh(new THREE.SphereGeometry(.34, 12, 8), new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false }));
  hit.position.x = .55; hit.userData.key = 'crank'; refs.crankSpin.add(hit); refs.pickables.push(hit); refs.crankMat = iron;
}

/* ── 木座日期窗：公曆日期與時刻、農曆、月相 ── */
const FACE_A = 4.3 * Math.cos(Math.PI / 12), FACE_Y = -1.53, drums = [];
const wrapPi = a => ((a + Math.PI) % TAU + TAU) % TAU - Math.PI;
const LP = ['初', '十', '二', '廿', '三'], LS = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'], DIGITS = '0123456789'.split('');
function buildWindows() {
  const W = refs.win = {}, hy = .15;
  const F = faceGroup(0), dw = .1, gap = .113;
  // 版面：年(4) 年 月(2) 月 日(2) 日 ｜ 時(2) : 分(2)
  const seq = [['d', 'year', 4], ['l', '年'], ['d', 'mon', 2], ['l', '月'], ['d', 'day', 2], ['l', '日'], ['s'], ['d', 'hh', 2], ['l', ':'], ['d', 'mm', 2]];
  const widths = seq.map(s => s[0] === 'd' ? s[2] * gap : s[0] === 'l' ? (s[1] === ':' ? .08 : .12) : .06), total = widths.reduce((a, b) => a + b, 0);
  let x = -total / 2; const holes = [], labels = [];
  seq.forEach((s, i) => {
    if (s[0] === 'd') { W[s[1]] = []; for (let k = 0; k < s[2]; k++) W[s[1]].push(addDrum(F, x + gap * (k + .5), DIGITS, dw, .28, true)); holes.push(rectHole(x - .01, x + widths[i] + .002, -hy, hy)); }
    else if (s[0] === 'l') labels.push({ text: s[1], x: x + widths[i] / 2, y: 0, size: .11 });
    x += widths[i];
  });
  labels.push({ text: '台灣時間', x: 0, y: -.27, size: .07 });
  makePlaque(F, 2.08, .8, holes, labels);
  const L = faceGroup(-30);
  W.gan = addDrum(L, -.86, GAN.split(''), .2, .27); W.zhi = addDrum(L, -.64, ZHI.split(''), .2, .23);
  W.leap = addDrum(L, -.30, ['', '閏', '', '閏'], .13, .3); W.lmon = addDrum(L, -.12, LMONTH, .2, .23);
  W.pre = addDrum(L, .27, LP, .2, .3); W.suf = addDrum(L, .49, LS, .2, .28);
  makePlaque(L, 2.08, .8, [rectHole(-.97, -.53, -hy, hy), rectHole(-.375, -.01, -hy, hy), rectHole(.16, .6, -hy, hy)],
    [{ text: '年', x: -.44, y: 0, size: .13 }, { text: '月', x: .075, y: 0, size: .13 }, { text: '農曆', x: .83, y: 0, size: .11 }, { text: '農曆初一為朔，十五前後為望', x: 0, y: -.27, size: .06 }]);
  const M = faceGroup(30), base = -.05, R = .3, hr = .15, arch = new THREE.Path();
  arch.moveTo(-R, base); arch.absarc(0, base, R, Math.PI, 0, true); arch.absarc(hr, base, hr, 0, Math.PI, false); arch.absarc(-hr, base, hr, 0, Math.PI, false);
  const discTex = canvasTex(512, 512, (ctx, w) => {
    const c = w / 2, g = ctx.createRadialGradient(c, c, 0, c, c, c); g.addColorStop(0, '#163a72'); g.addColorStop(1, '#0a1a3c'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, w);
    const r = rnd(5); for (let i = 0; i < 160; i++) { ctx.fillStyle = `rgba(240,215,160,${.4 + r() * .6})`; ctx.beginPath(); ctx.arc(r() * w, r() * w, r() * 2.2 + .6, 0, TAU); ctx.fill(); }
    [[c - 150, c], [c + 150, c]].forEach(([x, y]) => { const mg = ctx.createRadialGradient(x - 30, y - 30, 10, x, y, 105); mg.addColorStop(0, '#f6d9a0'); mg.addColorStop(.6, '#cf9a58'); mg.addColorStop(1, '#8a5a2a'); ctx.fillStyle = mg; ctx.beginPath(); ctx.arc(x, y, 105, 0, TAU); ctx.fill(); });
  });
  W.moonDisc = new THREE.Mesh(new THREE.CircleGeometry(.34, 64), new THREE.MeshStandardMaterial({ map: discTex, roughness: .45, metalness: .3 }));
  W.moonDisc.position.set(0, base, .2); M.add(W.moonDisc);
  makePlaque(M, 1.15, .78, [arch], [{ text: '月相', x: 0, y: .31, size: .08 }]);
}
let winKey = '';
function updateWindows(st, dt) {
  const W = refs.win; if (!W) return;
  const t = ymdOf(st.T), k = `${t.y}-${t.m}-${t.d}-${t.h}-${t.mi}`;
  if (k !== winKey) {
    const dayChanged = winKey.split('-').slice(0, 3).join('-') !== `${t.y}-${t.m}-${t.d}`; winKey = k;
    String(t.y).split('').forEach((c, i) => setDrum(W.year[i], +c));
    setDrum(W.mon[0], Math.floor(t.m / 10)); setDrum(W.mon[1], t.m % 10); setDrum(W.day[0], Math.floor(t.d / 10)); setDrum(W.day[1], t.d % 10);
    setDrum(W.hh[0], Math.floor(t.h / 10)); setDrum(W.hh[1], t.h % 10); setDrum(W.mm[0], Math.floor(t.mi / 10)); setDrum(W.mm[1], t.mi % 10);
    if (dayChanged) {
      const lunar = Solar.fromYmd(t.y, t.m, t.d).getLunar(), lm = lunar.getMonth(), dc = lunar.getDayInChinese();
      setDrum(W.gan, lunar.getYearGanIndex()); setDrum(W.zhi, lunar.getYearZhiIndex()); setDrum(W.leap, lm < 0 ? 1 : 0); setDrum(W.lmon, Math.abs(lm) - 1);
      setDrum(W.pre, LP.indexOf(dc[0])); setDrum(W.suf, LS.indexOf(dc[1]));
    }
  }
  const kk = reduced ? 1 : Math.min(1, dt * 9);
  drums.forEach(d => { d.a += (d.target - d.a) * kk; d.mesh.rotation.x = d.a; });
  W.moonDisc.rotation.z = -deg(st.E / 2);
}

/* ── 相機 ── */
let userZoomed = false, camMove = null, camTween = null;
function fitCamera() {
  const w = stage.clientWidth, h = stage.clientHeight, aspect = w / h; camera.aspect = aspect;
  const vf = deg(camera.fov), hf = 2 * Math.atan(Math.tan(vf / 2) * aspect), dist = 5.7 / Math.sin(Math.min(vf, hf) / 2) * (aspect < 1 ? .95 : .92);
  controls.minDistance = dist * .4; controls.maxDistance = dist * 1.5; camera.updateProjectionMatrix(); return dist;
}
function resetView() {
  camMove = null; controls.target.set(0, .55, 0); controls.maxPolarAngle = deg(95);
  const dist = fitCamera(), el = deg(30); camera.position.set(0, controls.target.y + dist * Math.sin(el), dist * Math.cos(el)); controls.update();
}
function applyQuality(name) {
  qName = name; Q = QUALITY[name];
  try { localStorage.setItem('orrery-quality', name); } catch (e) { /* 無法儲存時只在本次有效 */ }
  window.dispatchEvent(new CustomEvent('orrery-quality', { detail: name }));
  if (!renderer) return;
  renderer.setPixelRatio(Math.min(window.innerWidth < 700 ? Math.min(1.5, Q.pr) : Q.pr, window.devicePixelRatio || 1));
  const k = refs.key; k.castShadow = Q.shadow > 0;
  if (Q.shadow) { k.shadow.mapSize.set(Q.shadow, Q.shadow); if (k.shadow.map) { k.shadow.map.dispose(); k.shadow.map = null; } }
  resize(); requestRender();
}
function resize() { if (!renderer) return; renderer.setSize(stage.clientWidth, stage.clientHeight, false); if (!userZoomed) resetView(); else fitCamera(); sizeDust(); }
function focusWindows() {
  if (!renderer) return; controls.minDistance = 2; controls.maxPolarAngle = deg(92); camTween = null; userZoomed = true; $('hint').style.opacity = 0;
  const aspect = stage.clientWidth / stage.clientHeight, back = aspect < 1 ? 15.5 : 12.6, p1 = new THREE.Vector3(0, -.45, back), t1 = new THREE.Vector3(0, -1.3, 2.6);
  if (reduced) { camera.position.copy(p1); controls.target.copy(t1); return; }
  camMove = { p0: camera.position.clone(), q0: controls.target.clone(), p1, t1, t0: performance.now(), dur: 1300 };
}
function focusAz(az) {
  if (!renderer) return;
  const off = camera.position.clone().sub(controls.target), cur = Math.atan2(-off.z, off.x) / D2R, to = cur + wrap180(az - cur);
  if (reduced) { setCamAz(to); return; } camTween = { from: cur, to, t0: performance.now(), dur: 1100 };
}
function setCamAz(az) {
  const off = camera.position.clone().sub(controls.target), d = off.length(), el = Math.asin(clamp(off.y / d, -1, 1));
  camera.position.set(controls.target.x + d * Math.cos(el) * Math.cos(deg(az)), controls.target.y + d * Math.sin(el), controls.target.z - d * Math.cos(el) * Math.sin(deg(az)));
}
const focusBody = k => { const m = k === 'moon' ? refs.bodies.earth.moon : k === 'sun' ? null : refs.bodies[k] && refs.bodies[k].mesh; if (m) focusAz(Math.atan2(-m.position.z, m.position.x) / D2R); };

/* ════════════════════════════════════════════════════════════
   操作：拖曳地球／刻度環轉日期、鑰匙逐時推進、點擊查看
   ════════════════════════════════════════════════════════════ */
const HAS3 = typeof THREE !== 'undefined';
const ray = HAS3 ? new THREE.Raycaster() : null, ndc = HAS3 ? new THREE.Vector2() : null, dialPlane = HAS3 ? new THREE.Plane(new THREE.Vector3(0, 1, 0), -.03) : null;
let drag = null, hoverKey = null;
function setRay(ev) { const r = renderer.domElement.getBoundingClientRect(); ndc.set((ev.clientX - r.left) / r.width * 2 - 1, -(ev.clientY - r.top) / r.height * 2 + 1); ray.setFromCamera(ndc, camera); }
function dialAngle() { const p = new THREE.Vector3(); if (!ray.ray.intersectPlane(dialPlane, p)) return null; return { th: norm(Math.atan2(-p.z, p.x) / D2R), r: Math.hypot(p.x, p.z) }; }
function pick(ev) {
  setRay(ev);
  const hit = ray.intersectObjects(refs.pickables, false)[0];
  if (hit) return { type: 'body', key: hit.object.userData.key };
  const a = dialAngle(); if (!a) return null;
  if (a.r > 3.66 && a.r < 4.3) { const z = zodiacOf(a.th); const a0 = z[2], len = norm(z[3] - z[2]); return { type: 'zodiac', z, r0: 3.67, r1: 4.29, a0, len }; }
  if (a.r > 2.52 && a.r < 3.62) return { type: 'ring', r0: a.r > 3.08 ? 3.11 : 2.52, r1: a.r > 3.08 ? 3.61 : 3.05, a0: a.th - 3, len: 6 };
  return null;
}
const dragKind = h => !h ? null : (h.type === 'body' && h.key === 'earth') || h.type === 'zodiac' || h.type === 'ring' ? 'year' : (h.type === 'body' && h.key === 'crank') ? 'crank' : null;
const linkOf = h => h && h.type === 'body' && BODY[h.key] ? h.key : null;
function setHover(h) {
  requestRender();
  if (h && h.type !== 'body') { refs.hover.geometry.dispose(); refs.hover.geometry = new THREE.RingGeometry(h.r0, h.r1, 24, 1, deg(h.a0), deg(h.len)).rotateX(-Math.PI / 2); refs.hover.position.y = h.r0 < 3.08 ? .05 : .008; refs.hover.visible = true; }
  else refs.hover.visible = false;
  setLink(linkOf(h)); const c = renderer.domElement; c.classList.toggle('pick', !!h); c.style.cursor = dragKind(h) ? 'var(--cur-grab)' : '';
}
function bindPointer() {
  const el = renderer.domElement;
  glBox.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    const h = pick(e), kind = dragKind(h);
    drag = { h, kind, x0: e.clientX, y0: e.clientY, moved: false, T0: Tcur, acc: 0 };
    if (!kind) return;
    e.stopPropagation(); e.preventDefault(); const a = dialAngle(); drag.th = a ? a.th : 0;
    controls.enabled = false; el.style.cursor = 'var(--cur-grabbing)'; setPlaying(false);
  }, { capture: true });
  window.addEventListener('pointermove', e => {
    if (drag && drag.kind) {
      if (Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) > 5) drag.moved = true;
      if (!drag.moved) return; setRay(e);
      if (drag.kind === 'crank') setTime(drag.T0 + Math.round(((e.clientX - drag.x0) - (e.clientY - drag.y0)) / 8) / 24, { live: true });
      else { const a = dialAngle(); if (!a) return; drag.acc += wrap180(a.th - drag.th); drag.th = a.th; setTime(drag.T0 + drag.acc * 365.256 / 360, { live: true }); }
      return;
    }
    if (e.pointerType !== 'mouse' || e.buttons || e.target !== el) return;
    const h = pick(e), k = h ? h.type + (h.key || (h.z && h.z[0]) || '') : null;
    if (k !== hoverKey) { hoverKey = k; setHover(h); }
  });
  // 瀏覽器接手捲動時會取消拖曳，這時要恢復視角控制
  window.addEventListener('pointercancel', () => { if (drag) { drag = null; scrubbing = false; controls.enabled = true; el.style.cursor = ''; } });
  window.addEventListener('pointerup', e => {
    if (!drag) return; const d = drag; drag = null; controls.enabled = true; el.style.cursor = '';
    if (d.kind && d.moved) { scrubbing = false; lastPanelNight = ''; return; }
    if (Math.hypot(e.clientX - d.x0, e.clientY - d.y0) > 6 || !d.h) return;
    const h = d.h;
    if (h.type === 'body') {
      if (h.key === 'crank') setTime(Tshow() + 1 / 24, { add: 500 });   // 鑰匙：連點時每次累加一小時
      else if (h.key === 'windows') focusWindows();
      else showBody(h.key);
    } else if (h.type === 'zodiac') showZodiac(h.z);
  });
  el.addEventListener('pointerleave', () => { if (!drag) { hoverKey = null; setHover(null); } });
  controls.addEventListener('start', () => { $('hint').style.opacity = 0; interactUntil = Infinity; });
  controls.addEventListener('end', () => { interactUntil = performance.now() + 1200; });
  el.addEventListener('wheel', () => { interactUntil = performance.now() + 800; }, { passive: true });
  el.addEventListener('wheel', () => { userZoomed = true; }, { passive: true });
}
let litKey = null;
function setLink(key) {
  if (key === litKey) return; litKey = key; requestRender();
  document.querySelectorAll('[data-link]').forEach(el => el.classList.toggle('lit', el.dataset.link === key));
  if (!renderer) return;
  ORDER.forEach(k => { const b = refs.bodies[k], on = k === key; b.mat.emissive.setHex(on ? 0x3a2810 : 0); b.hoopMat.emissive.setHex(on ? BODY[k].hex : 0); b.hoopMat.emissiveIntensity = on ? .5 : 0; });
  Object.entries(refs.beads).forEach(([k, bd]) => { const on = k === key; bd.beamMat.opacity = on ? 1 : key ? .15 : .5; bd.glow.material.opacity = on ? 1 : .55; });
}

/* ════════════════════════════════════════════════════════════
   時間：天文儀、窗口與面板共用同一個時間 Tcur（本地民用儒略日）
   ════════════════════════════════════════════════════════════ */
let Tcur = 0, tween = null, playing = false, speed = 7, scrubbing = false, alpha = 0, cageA = 0, clock = 0;
const ease = x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
const Tmin = jdOf(YEAR_MIN, 1, 2), Tmax = jdOf(YEAR_MAX, 12, 31);
/* 時間動畫
   - 目標時刻 tween.T1 一確定，面板與日曆就立即顯示結果；天文儀再以等速動畫追上目標
   - 動畫進行中再次按下按鈕：不中斷、不重新起步，把目標往後累加，並把剩餘時長加上這次的時長，繼續等速前進
   opts.add：這次操作要增加的動畫時長（毫秒）；opts.abs：指定絕對日期（跨越多年時直接跳到附近再播放）*/
const Tshow = () => tween ? tween.T1 : Tcur;          // 面板顯示用的時刻：動畫中顯示目標
function setTime(T, opts = {}) {
  T = clamp(T, Tmin, Tmax);
  if (opts.live) { tween = null; scrubbing = true; Tcur = T; return; }
  setPlaying(false);
  if (reduced || opts.dur === 0) { Tcur = T; tween = null; return; }
  let secs;
  if (tween) {
    if (opts.abs && Math.abs(T - Tcur) > 730) { Tcur = T - Math.sign(T - Tcur) * 90; secs = 2; }
    else secs = Math.abs(tween.T1 - Tcur) / tween.rate + (opts.add || 600) / 1000;   // 剩餘時長 + 這次增加的時長
  } else {
    if (opts.abs && Math.abs(T - Tcur) > 730) Tcur = T - Math.sign(T - Tcur) * 90;   // 跨越多年時，只播放最後三個月
    const span = Math.abs(T - Tcur);
    secs = (opts.dur || opts.add || (span < .2 ? 500 : span < 3 ? 900 : span < 60 ? 1400 : 2000)) / 1000;
  }
  const span = Math.abs(T - Tcur);
  if (span < 1e-7) { Tcur = T; tween = null; return; }
  tween = { T1: T, rate: span / secs };                 // rate：每秒前進的天數
}
function setPlaying(on) {
  if (on === playing) return; playing = on;
  const b = $('playBtn'); b.setAttribute('aria-pressed', on); b.textContent = on ? '❚❚ 暫停' : '▶ 推進時光';
  if (on) tween = null;
}
let lastFrame = performance.now(), lastSnapT = null, snap = null, lastGearT = 0, lastPanelNight = '', lastPanelMin = '';
let needRender = true, interactUntil = 0, lastRender = 0, accDt = 0, stageVisible = true;
const requestRender = () => { needRender = true; };
if ('IntersectionObserver' in window) new IntersectionObserver(es => { stageVisible = es[0].isIntersecting; if (stageVisible) needRender = true; }).observe(stage);
function frame(now) {
  const dt = Math.min(.05, (now - lastFrame) / 1000); lastFrame = now;
  if (tween) { const d = tween.T1 - Tcur, step = tween.rate * dt; if (Math.abs(d) <= step) { Tcur = tween.T1; tween = null; } else Tcur += Math.sign(d) * step; }
  else if (playing) { Tcur += dt * speed; if (Tcur >= Tmax) { Tcur = Tmax; setPlaying(false); } }
  if (Tcur !== lastSnapT) { snap = snapshot(Tcur); lastSnapT = Tcur; }
  updatePanels();
  accDt += dt;
  const busy = tween || playing || scrubbing || drag || camMove || camTween || now < interactUntil || needRender;
  if (renderer && stageVisible && (busy || now - lastRender >= 1000 / Q.idleFps)) {
    const rdt = Math.min(.2, accDt); accDt = 0; lastRender = now; needRender = false;
    alpha += clamp((Tcur - lastGearT) * 2.5, -.3, .3); lastGearT = Tcur;
    if (!reduced) { clock += rdt; cageA += rdt * TAU / 60; }
    repaintCalendar(ymdOf(Tcur).y);
    applySnapshot(snap, rdt); applyGears(); animateExtras(rdt); updateWindows(snap, rdt);
    renderer.shadowMap.needsUpdate = true;
    if (camMove) { const e = ease(clamp((now - camMove.t0) / camMove.dur, 0, 1)); camera.position.lerpVectors(camMove.p0, camMove.p1, e); controls.target.lerpVectors(camMove.q0, camMove.t1, e); if (e >= 1) camMove = null; }
    if (camTween) { const e = ease(clamp((now - camTween.t0) / camTween.dur, 0, 1)); setCamAz(camTween.from + (camTween.to - camTween.from) * e); if (e >= 1) camTween = null; }
    controls.update(); renderer.render(scene, camera);
  }
  requestAnimationFrame(frame);
}

/* ════════════════════════════════════════════════════════════
   面板
   ════════════════════════════════════════════════════════════ */
let lastSkyT = 0;
let lastReadKey = '', targetSnap = null;
function updatePanels() {
  const TS = Tshow(), t = ymdOf(TS), nd = nightOf(TS), nKey = `${locKey()}|${nd.y}-${nd.m}-${nd.d}`, mKey = `${t.y}-${t.m}-${t.d}-${t.h}-${t.mi}`;
  // 右上角：天文儀目前轉到的時刻
  const rt = ymdOf(Tcur), rKey = `${rt.y}-${rt.m}-${rt.d}-${rt.h}-${rt.mi}|${!!tween}|${playing}|${scrubbing}`;
  if (rKey !== lastReadKey) {
    lastReadKey = rKey;
    const live = playing || scrubbing || !!tween;
    $('orrLabel').textContent = playing ? '推進中' : tween ? '運轉中' : scrubbing ? '轉動中' : '儀器指示';
    $('readout').className = 'readout-box' + (live ? ' live' : '');
    $('orrDate').textContent = `${rt.y}年${rt.m}月${rt.d}日 ${pad(rt.h)}:${pad(rt.mi)}`;
  }
  if (mKey !== lastPanelMin) {
    lastPanelMin = mKey;
    $('wMD').innerHTML = `${t.m}<small>月</small>${t.d}<small>日</small>`;
    $('wTime').textContent = `${pad(t.h)}:${pad(t.mi)}`;
    const lunar = Solar.fromYmd(t.y, t.m, t.d).getLunar(), lm = lunar.getMonth();
    $('wYW').textContent = `${t.y} 年　星期${WEEK[Solar.fromYmd(t.y, t.m, t.d).getWeek()]}　農曆${lm < 0 ? '閏' : ''}${LMONTH[Math.abs(lm) - 1]}月${lunar.getDayInChinese()}`;
    const mo = Math.round((TS - (jdOf(nd.y, nd.m, nd.d) + .5)) * 1440);
    const sv = clamp(mo - 300, 0, 840); $('timeSlider').value = sv; $('sliderTime').textContent = `${pad(t.h)}:${pad(t.mi)}`;
    $('dateInput').value = `${nd.y}-${pad(nd.m)}-${pad(nd.d)}`;
  }
  const busy = playing || scrubbing;                    // 按鈕動畫時目標已確定，面板立即更新；只有連續推進或拖曳時才節流
  if (nKey !== lastPanelNight && (!busy || performance.now() - lastSkyT > 250)) { lastPanelNight = nKey; renderNight(nd); renderPlanets(nd); renderEvents(nd); renderGrid(nd); renderPlanner(); }
  if (performance.now() - lastSkyT > (busy ? 120 : 0) && TS !== drawSky.lastT) {
    lastSkyT = performance.now();
    if (!targetSnap || targetSnap.T !== TS) targetSnap = TS === Tcur && snap ? snap : snapshot(TS);
    drawSky(targetSnap, nd);
  }
}
const moonPhaseName = E => E < 12 || E >= 348 ? '新月' : E < 80 ? '眉月' : E < 100 ? '上弦月' : E < 168 ? '盈凸月' : E < 192 ? '滿月' : E < 260 ? '虧凸月' : E < 280 ? '下弦月' : '殘月';
function moonIcon(E, R = 12, cls = 'moon-disc') {
  const rx = Math.round(R * Math.abs(Math.cos(deg(E))) * 100) / 100;
  const d = E < 180 ? `M0,${-R}A${R},${R} 0 0 1 0,${R}A${rx},${R} 0 0 ${E < 90 ? 0 : 1} 0,${-R}Z` : `M0,${-R}A${R},${R} 0 0 0 0,${R}A${rx},${R} 0 0 ${E < 270 ? 0 : 1} 0,${-R}Z`;
  return `<svg class="${cls}" viewBox="${-R - 1} ${-R - 1} ${2 * R + 2} ${2 * R + 2}" aria-hidden="true"><circle r="${R}" fill="#1c2a47" stroke="rgba(217,222,230,.5)" stroke-width=".8"/><path d="${d}" fill="#efe6cc"/></svg>`;
}
const GRADE = ['', '不佳', '普通', '良好', '極佳'];
function renderNight(nd) {
  const n = nightInfo(nd), hm = m => `${Math.floor(m / 60)} 小時 ${m % 60} 分`;
  $('gradeChip').className = 'grade g' + n.grade; $('gradeChip').textContent = GRADE[n.grade];
  $('nightLabel').textContent = `${nd.m}/${nd.d} 晚上至隔天清晨`;
  const segs = n.segs.length ? n.segs.map(s => `${fmtHM(s.a)}–${fmtHM(s.b)}`).join('、') : '無';
  $('nightRows').innerHTML = `
    <div><dt>無月暗夜</dt><dd><b>${segs}</b><span class="muted">共 ${hm(n.darkMin)}</span></dd></div>
    <div><dt>月亮</dt><dd>${moonIcon(n.E)}${moonPhaseName(n.E)}，照明 ${Math.round(n.illum * 100)}%<span class="muted">月出 ${fmtHM(n.moonrise)}，月落 ${fmtHM(n.moonset)}</span></dd></div>
    <div><dt>日落／日出</dt><dd>${fmtHM(n.sunset)} ／ ${fmtHM(n.sunrise)}</dd></div>
    <div><dt>天空全暗</dt><dd>${fmtHM(n.dusk)} 至 ${fmtHM(n.dawn)}<span class="muted">太陽低於地平 18°</span></dd></div>`;
}
function renderPlanets(nd) {
  const n = nightInfo(nd), rows = [];
  for (const p of A.PLANETS) {
    const q = S.planetNight(p, n, loc), z = zodiacOf(A.geoPlanet(p, (n.t0 + n.t1) / 2).lon);
    const long = q.segs.filter(s => s.b - s.a >= 20 / 1440);
    let vis;
    if (q.elong < 12) vis = `<span class="muted">太接近太陽，看不到</span>`;
    else if (!long.length) vis = `<span class="muted">只在白天升起，夜間看不到</span>`;
    else vis = long.map(s => `${fmtHM(s.a)}–${fmtHM(s.b)}`).join('、') + `<br><span class="muted">${q.dir}方天空，最高約 ${Math.round(q.best.alt)}°</span>`;
    rows.push(`<tr data-link="${p}" tabindex="0"><td class="nm"><i class="dot" style="--c:var(--${p})"></i>${BODY[p].name}${q.retro ? '<span class="tag">逆行</span>' : ''}</td><td>${z[0]}</td><td>${q.mag.toFixed(1)} 等</td><td>${vis}</td></tr>`);
  }
  $('pBody').innerHTML = rows.join('');
  $('pBody').querySelectorAll('tr').forEach(tr => {
    tr.addEventListener('mouseenter', () => setLink(tr.dataset.link)); tr.addEventListener('mouseleave', () => setLink(null));
    const go = () => { focusBody(tr.dataset.link); showBody(tr.dataset.link); };
    tr.addEventListener('click', go); tr.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  });
}
function renderEvents(nd) {
  const j0 = jdOf(nd.y, nd.m, nd.d), list = eventsFor(j0, j0 + 60).filter(e => e.t + TZ >= j0 + .5);
  const shown = list.filter(e => e.type !== 'phase' || list.length < 10).slice(0, 14);
  $('evList').innerHTML = shown.length ? shown.map((e, i) => `<li class="${e.major ? 'major' : ''} ${e.type}"><button data-i="${i}"><span class="d">${fmtMD(e.t)} ${fmtHM(e.t)}</span><span class="t">${e.text}</span></button></li>`).join('') : '<li class="muted">這段期間沒有特別的天象</li>';
  $('evList').querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
    const e = shown[+b.dataset.i], T = e.t + TZ, tl = ymdOf(T);
    // 白天發生的事件，改看當晚 21:00
    const hour = tl.h + tl.mi / 60, night = hour >= 18 || hour < 6;
    setTime(night ? T : jdOf(tl.y, tl.m, tl.d) + 21 / 24, { abs: true });
    if (e.body) focusBody(e.body);
  }));
}
function renderGrid(nd) {
  const { y, m } = nd;
  $('monthTitle').innerHTML = `<span>${y}</span>年<span>${m}</span>月`;
  const grid = $('grid'); grid.innerHTML = '';
  for (let i = 0; i < 7; i++) { const h = document.createElement('div'); h.className = 'wd'; h.textContent = WEEK[i]; grid.appendChild(h); }
  const start = jdOf(y, m, 1) - Solar.fromYmd(y, m, 1).getWeek(), evs = eventsFor(start, start + 42);
  const tn = nightOf(nowLocal());
  for (let i = 0; i < 42; i++) {
    const c = ymdOf(start + i + .5);
    if (c.y < YEAR_MIN || c.y > YEAR_MAX) { grid.appendChild(document.createElement('span')); continue; }
    const n = nightInfo(c), lunar = Solar.fromYmd(c.y, c.m, c.d).getLunar(), j = jdOf(c.y, c.m, c.d);
    const ev = evs.filter(e => { const lt = e.t + TZ; return lt >= j + .25 && lt < j + 1.25 && e.type !== 'phase'; })
      .sort((a, b) => (b.type === 'eclipse') - (a.type === 'eclipse') || (b.major ? 1 : 0) - (a.major ? 1 : 0))[0];
    const hol = P.holidayOn(c), pev = P.eventsOn(`${c.y}-${c.m}-${c.d}`), ans = P.annivsOn(c);
    const b = document.createElement('button');
    b.className = 'cell' + (c.m !== m ? ' out' : '') + (ev ? ' ev' : '') + (sameDay(c, nd) ? ' sel' : '') + (sameDay(c, tn) ? ' today' : '') + (hol ? (hol.off ? ' hol' : ' work') : '') + (P.blockOn(c) ? ' lj' : '');
    b.innerHTML = `${moonIcon(n.E, 5, 'mp')}<span class="n">${c.d}</span><span class="s">${ev ? shortOf(ev) : lunar.getDayInChinese()}</span>${hol ? `<span class="hn">${hol.short}</span>` : ''}<span class="pm" aria-hidden="true">${pev.length ? '<i class="evd"></i>' : ''}${ans.length ? '<i class="and">♥</i>' : ''}</span><i class="bar g${n.grade}" style="width:calc(${Math.min(1, n.darkMin / 600) * 100}% - 8px)"></i>`;
    b.setAttribute('aria-label', `${c.y}年${c.m}月${c.d}日晚上，觀星條件${GRADE[n.grade]}，無月暗夜 ${Math.floor(n.darkMin / 60)} 小時${ev ? '，' + ev.text : ''}${hol ? '，' + hol.name : ''}${ans.length ? '，紀念日：' + ans.map(a => a.name).join('、') : ''}${pev.length ? `，${pev.length} 個行程` : ''}`);
    b.addEventListener('click', () => { const mo = Math.round((Tshow() - (jdOf(nd.y, nd.m, nd.d) + .5)) * 1440); setTime(jdOf(c.y, c.m, c.d) + .5 + clamp(mo, 0, 1439) / 1440, { abs: true }); });
    grid.appendChild(b);
  }
}
/* ── 夜空圖：等距方位投影，北方在上、東方在左（抬頭仰望時的方向） ── */
function drawSky(st, nd) {
  drawSky.lastT = st.T;
  const jd = st.jd, lst = A.gmst(jd) + loc.lon, eps = A.obliq(jd), pr = A.precess(jd), R = 150;
  const xy = (alt, az) => { const r = R * (90 - alt) / 90; return [-r * Math.sin(deg(az)), -r * Math.cos(deg(az))]; };
  const hz = (ra, dec) => A.altAz(ra, dec, loc.lat, lst);
  const sunEq = A.bodyEq('sun', jd), sunH = hz(sunEq.ra, sunEq.dec).alt;
  const sky = sunH > 0 ? '#3d6aa6' : sunH > -6 ? '#28406e' : sunH > -12 ? '#1a2a52' : sunH > -18 ? '#111d3e' : '#08122c';
  let s = `<defs><radialGradient id="skyG"><stop offset="0" stop-color="${sky}"/><stop offset="1" stop-color="${sky}" stop-opacity=".75"/></radialGradient></defs>
    <circle r="${R}" fill="url(#skyG)" stroke="rgba(234,208,140,.6)" stroke-width="1.5"/>
    <circle r="${R * 2 / 3}" fill="none" stroke="rgba(234,208,140,.15)"/><circle r="${R / 3}" fill="none" stroke="rgba(234,208,140,.15)"/>`;
  [['北', 0], ['東', 90], ['南', 180], ['西', 270]].forEach(([t, az]) => { const [x, y] = xy(-9, az); s += `<text x="${x}" y="${y}" fill="#ead08c" font-size="14" text-anchor="middle" dominant-baseline="central" font-weight="700">${t}</text>`; });
  // 黃道：行星都在這條線附近
  let path = '', pen = false;
  for (let l = 0; l <= 360; l += 4) { const q = A.eclToEq(l + pr, 0, eps), h = hz(q.ra, q.dec); if (h.alt > 0) { const [x, y] = xy(h.alt, h.az); path += (pen ? 'L' : 'M') + x.toFixed(1) + ',' + y.toFixed(1); pen = true; } else pen = false; }
  s += `<path d="${path}" fill="none" stroke="rgba(234,208,140,.35)" stroke-dasharray="3 4"/>`;
  const starVis = sunH < -6;
  STARS.forEach(([name, ra, dec, mag]) => {
    const e = A.eqToEcl(ra, dec, 23.4393), q = A.eclToEq(e.lon + pr, e.lat, eps), h = hz(q.ra, q.dec);
    if (h.alt <= 0 || !starVis) return;
    const [x, y] = xy(h.alt, h.az), r = Math.max(1, 3.2 - mag * .9);
    s += `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff8e8"/>`;
    if (mag < 1.3 || name === '北極星') s += `<text x="${x + 5}" y="${y - 4}" fill="rgba(242,231,203,.7)" font-size="10">${name}</text>`;
  });
  const bodies = [];
  for (const p of A.PLANETS) { const q = A.bodyEq(p, jd), h = hz(q.ra, q.dec); bodies.push([p, h]); }
  const mq = A.bodyEq('moon', jd), mh = hz(mq.ra, mq.dec);
  if (sunH > -0.8) { const [x, y] = xy(Math.max(sunH, 0), hz(sunEq.ra, sunEq.dec).az); if (sunH > 0) s += `<circle cx="${x}" cy="${y}" r="9" fill="#ffd27a"/><text x="${x + 11}" y="${y + 4}" fill="#ffd27a" font-size="12">太陽</text>`; }
  if (mh.alt > 0) { const [x, y] = xy(mh.alt, mh.az); s += `<g transform="translate(${x},${y})">${moonIcon(st.E, 7, '').replace('<svg class="" ', '<svg x="-8" y="-8" width="16" height="16" ')}</g><text x="${x + 10}" y="${y + 4}" fill="#d9dee6" font-size="12">月</text>`; }
  bodies.forEach(([p, h]) => {
    if (h.alt <= 0) return;
    const [x, y] = xy(h.alt, h.az), col = `var(--${p})`;
    s += `<g data-link="${p}" style="cursor:pointer"><circle cx="${x}" cy="${y}" r="5" fill="${col}" stroke="#08122c"/><text x="${x + 7}" y="${y + 4}" fill="${col}" font-size="12" font-weight="700">${BODY[p].name}</text></g>`;
  });
  const below = bodies.filter(([, h]) => h.alt <= 0).map(([p]) => BODY[p].name);
  s += `<text x="0" y="${R + 34}" fill="rgba(169,180,201,.9)" font-size="11" text-anchor="middle">${below.length ? '地平線下：' + below.join('、') : '五顆行星都在地平線上'}</text>`;
  const svg = $('skyChart'); svg.innerHTML = s;
  svg.querySelectorAll('[data-link]').forEach(g => { g.addEventListener('mouseenter', () => setLink(g.dataset.link)); g.addEventListener('mouseleave', () => setLink(null)); g.addEventListener('click', () => { focusBody(g.dataset.link); showBody(g.dataset.link); }); });
}

/* ════════════════════════════════════════════════════════════
   十一之二、生活功能（PHP 版）
   行程、紀念日、學習進度、天氣地點、國定假日、每日學習、鄉鎮天氣
   資料一律透過伺服器的 api/*.php 讀寫；瀏覽器只負責畫面
   ════════════════════════════════════════════════════════════ */
const APP = window.APP || { version: '', api: 'api/' };
/* 呼叫 PHP API：回傳 JSON；伺服器回報錯誤時丟出例外 */
async function api(path, opts = {}) {
  const init = { headers: { Accept: 'application/json' }, ...opts };
  if (opts.body) init.headers['Content-Type'] = 'application/json';
  const r = await fetch(APP.api + path, init);
  let d; try { d = await r.json(); } catch (e) { throw new Error('伺服器回應不是 JSON，請確認是透過 XAMPP 開啟'); }
  if (!r.ok || d.ok === false) throw new Error(d.error || `HTTP ${r.status}`);
  return d;
}
const SEL = () => nightOf(Tshow());                      // 觀星版以「觀測夜」作為選取的日期
const selectDate = (y, m, d) => setTime(jdOf(y, m, d) + 21 / 24, { abs: true });
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const wdOf = jd => Math.floor(jd + 1.5) % 7;
const keyOf = c => `${c.y}-${c.m}-${c.d}`;
const P = (() => {
  let state = { events: [], annivs: [], learned: {}, wx: null }, online = false;
  const note = t => { const n = $('storeNote'); if (n) n.textContent = t; };
  async function loadState() {
    try { const d = await api('planner.php'); state = d.state; online = true; note(`資料儲存在 PHP 伺服器上（v${APP.version}）。`); refresh(); }
    catch (e) { note(`無法連線到 PHP 伺服器：${e.message}。請用 XAMPP 啟動 Apache，再從 http://localhost/ 開啟。`); }
  }
  /* 寫入操作：送到伺服器，伺服器回傳最新的完整資料 */
  async function op(body) {
    if (!online) { note('目前沒有連線到 PHP 伺服器，無法儲存。'); return; }
    try { const d = await api('planner.php', { method: 'POST', body: JSON.stringify(body) }); state = d.state; refresh(); }
    catch (e) { note(`儲存失敗：${e.message}`); }
  }

  /* ── 國定假日：向 api/holidays.php 取得官方資料；沒有官方資料的年份，在瀏覽器依法規推算 ── */
  const holApi = new Map();            // 年份 → 'loading' | 'error' | API 回傳的資料
  function fetchYear(y) {
    if (holApi.has(y) || y < YEAR_MIN || y > YEAR_MAX + 1) return;
    holApi.set(y, 'loading');
    api(`holidays.php?year=${y}`).then(d => holApi.set(y, d)).catch(() => holApi.set(y, 'error')).finally(() => {
      holCache.delete(y); blockCache.clear();
      const nd = nightOf(Tshow()); renderGrid(nd); renderDay(); renderUpcoming();
    });
  }
  const OFF_SHORT = { '開國紀念日': '元旦', '農曆除夕': '除夕', '小年夜': '小年夜', '春節': '春節', '補假': '補假', '調整放假': '彈性放假', '調整上班': '補班', '補行上班': '補班',
    '和平紀念日': '和平紀念', '兒童節': '兒童節', '兒童節及民族掃墓節': '兒童清明', '民族掃墓節': '清明', '清明節': '清明', '勞動節': '勞動節', '端午節': '端午', '中秋節': '中秋',
    '國慶日': '國慶', '臺灣光復暨金門古寧頭大捷紀念日': '光復節', '行憲紀念日': '行憲', '放假': '放假' };
  const shortName = d => OFF_SHORT[d] || (d.startsWith('孔子誕辰') ? '教師節' : d.slice(0, 4));
  function ruleList(y) {               // 依《紀念日及節日實施條例》推算（無官方資料的年份）
    const list = [], add = (jd, name, short, grp) => list.push({ jd, name, short, grp });
    const J = (m, d) => jdOf(y, m, d);
    const LJ = (lm, ld) => { const s = Lunar.fromYmd(y, lm, ld).getSolar(); return jdOf(s.getYear(), s.getMonth(), s.getDay()); };
    add(J(1, 1), '開國紀念日', '元旦');
    const cny = LJ(1, 1);
    if (y >= 2026) add(cny - 2, '小年夜', '小年夜', 'spring');
    add(cny - 1, '農曆除夕', '除夕', 'spring');
    [0, 1, 2].forEach(k => add(cny + k, '春節', '春節', 'spring'));
    add(J(2, 28), '和平紀念日', '和平紀念');
    const qs = Solar.fromYmd(y, 6, 1).getLunar().getJieQiTable()['清明'], qmJ = jdOf(qs.getYear(), qs.getMonth(), qs.getDay());
    let kid = J(4, 4); if (kid === qmJ) kid += wdOf(kid) === 4 ? 1 : -1;
    add(kid, '兒童節', '兒童節'); add(qmJ, '清明節', '清明');
    if (y >= 2026) add(J(5, 1), '勞動節', '勞動節');
    add(LJ(5, 5), '端午節', '端午'); add(LJ(8, 15), '中秋節', '中秋');
    if (y >= 2025) add(J(9, 28), '孔子誕辰紀念日/教師節', '教師節');
    add(J(10, 10), '國慶日', '國慶');
    if (y >= 2025) { add(J(10, 25), '臺灣光復暨金門古寧頭大捷紀念日', '光復節'); add(J(12, 25), '行憲紀念日', '行憲'); }
    const off = new Set(list.map(h => h.jd)), work = jd => wdOf(jd) !== 0 && wdOf(jd) !== 6 && !off.has(jd);
    const spring = list.filter(h => h.grp === 'spring');
    let need = spring.filter(h => [0, 6].includes(wdOf(h.jd))).length, d = Math.max(...spring.map(h => h.jd)) + 1;
    while (need > 0) { if (work(d)) { list.push({ jd: d, name: '補假', short: '補假' }); off.add(d); need--; } d++; }
    list.filter(h => !h.grp && h.short !== '補假').sort((a, b) => a.jd - b.jd).forEach(h => {
      const w = wdOf(h.jd); if (w !== 0 && w !== 6) return;
      const step = w === 6 ? -1 : 1; let x = h.jd + step; while (!work(x)) x += step;
      list.push({ jd: x, name: '補假', short: '補假' }); off.add(x);
    });
    return list;
  }
  const holCache = new Map();
  function holidaysOf(y) {
    if (holCache.has(y)) return holCache.get(y);
    const a = holApi.get(y); if (!a) fetchYear(y);
    const map = new Map(), official = !!(a && a.official);
    if (official) Object.entries(a.days).forEach(([md, [off, desc]]) => {
      const m = +md.slice(0, 2), d = +md.slice(2), c = { y, m, d };
      map.set(keyOf(c), { name: desc || (off ? '放假' : '上班'), short: shortName(desc), off: !!off, c, jd: jdOf(y, m, d) });
    });
    else if (y >= YEAR_MIN && y <= YEAR_MAX + 1) ruleList(y).sort((a, b) => a.jd - b.jd).forEach(h => {
      const c = ymdOf(h.jd + .5), k = keyOf(c);
      if (!map.has(k)) map.set(k, { name: h.name, short: h.short, off: true, c, jd: h.jd, guess: true });
    });
    const res = { list: [...map.values()].sort((a, b) => a.jd - b.jd), map, official };
    if (a && a !== 'loading') holCache.set(y, res);          // 還在等 API 時先不快取，回來後重畫
    return res;
  }
  const holidayOn = c => holidaysOf(c.y).map.get(keyOf(c)) || (c.m === 12 && !holidaysOf(c.y).official ? holidaysOf(c.y + 1).map.get(keyOf(c)) : null);
  const isOff = c => { const h = holidayOn(c); return h ? h.off : [0, 6].includes(wdOf(jdOf(c.y, c.m, c.d))); };
  const PRI = ['春節', '除夕', '小年夜', '元旦', '和平紀念', '兒童清明', '兒童節', '清明', '勞動節', '端午', '中秋', '教師節', '國慶', '光復節', '行憲'];
  const blockCache = new Map();
  function blockOn(c) {
    const k = keyOf(c); if (blockCache.has(k)) return blockCache.get(k);
    let res = null;
    if (isOff(c)) {
      const j = jdOf(c.y, c.m, c.d); let a = j, b = j;
      while (a - j > -20 && isOff(ymdOf(a - 1 + .5))) a--;
      while (b - j < 20 && isOff(ymdOf(b + 1 + .5))) b++;
      const hs = []; for (let x = a; x <= b; x++) { const h = holidayOn(ymdOf(x + .5)); if (h && h.off) hs.push(h); }
      if (b - a + 1 >= 3 && hs.length) {
        const main = PRI.find(p => hs.some(h => h.short === p));
        res = { len: b - a + 1, idx: j - a + 1, name: (main || '國定') + '連假', start: ymdOf(a + .5), end: ymdOf(b + .5), guess: hs.some(h => h.guess) };
      }
    }
    blockCache.set(k, res); return res;
  }

  /* ── 行程與紀念日 ── */
  const eventsOn = key => state.events.filter(e => e.date === key).sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
  function annivDate(a, Y) {
    if (a.type === 'solar') return { y: Y, m: a.m, d: Math.min(a.d, dim(Y, a.m)) };
    for (const LY of [Y - 1, Y]) {
      if (LY < YEAR_MIN - 1) continue;
      const n = LunarMonth.fromYm(LY, a.m); if (!n) continue;
      const s = Lunar.fromYmd(LY, a.m, Math.min(a.d, n.getDayCount())).getSolar();
      if (s.getYear() === Y) return { y: Y, m: s.getMonth(), d: s.getDay(), ly: LY };
    }
    return null;
  }
  const annivYears = (a, oc) => (a.type === 'solar' ? oc.y : oc.ly) - a.y0;
  const annivsOn = c => state.annivs.filter(a => { const o = annivDate(a, c.y); return o && o.m === c.m && o.d === c.d; });
  const DAYS = ['初一','初二','初三','初四','初五','初六','初七','初八','初九','初十','十一','十二','十三','十四','十五','十六','十七','十八','十九','二十','廿一','廿二','廿三','廿四','廿五','廿六','廿七','廿八','廿九','三十'];
  const annivDesc = a => a.type === 'solar' ? `每年國曆 ${a.m} 月 ${a.d} 日` : `每年農曆${LMONTH[a.m - 1]}月${DAYS[a.d - 1]}`;

  function renderDay() {
    const c = SEL(), key = keyOf(c), hol = holidayOn(c), evs = eventsOn(key), ans = annivsOn(c);
    $('dayTitle').textContent = `${c.m} 月 ${c.d} 日（星期${WEEK[Solar.fromYmd(c.y, c.m, c.d).getWeek()]}）`;
    const rows = [];
    if (hol) rows.push(hol.off ? `<li class="it hol"><i class="ic">假</i><span>${esc(hol.name)}${hol.guess ? '<small>依法規推算，尚無官方公告</small>' : ''}</span></li>`
                               : `<li class="it wk"><i class="ic">補班</i><span>${esc(hol.name)}<small>這天要上班</small></span></li>`);
    const blk = blockOn(c);
    if (blk) rows.push(`<li class="it lj"><i class="ic">連假</i><span>${blk.name}第 ${blk.idx} 天，共 ${blk.len} 天<small>${blk.start.m}/${blk.start.d}（${WEEK[wdOf(jdOf(blk.start.y, blk.start.m, blk.start.d))]}）至 ${blk.end.m}/${blk.end.d}（${WEEK[wdOf(jdOf(blk.end.y, blk.end.m, blk.end.d))]}）${blk.guess ? '，依法規推算' : ''}</small></span></li>`);
    ans.forEach(a => { const n = annivYears(a, annivDate(a, c.y)); rows.push(`<li class="it an"><i class="ic">♥</i><span>${esc(a.name)}<small>${n > 0 ? `第 ${n} 週年` : '從今天開始'}，${annivDesc(a)}</small></span><button class="del" data-an="${esc(a.id)}" aria-label="移除紀念日 ${esc(a.name)}">移除</button></li>`); });
    evs.forEach(e => rows.push(`<li class="it ev"><i class="ic">${e.time ? esc(e.time) : '全天'}</i><span>${esc(e.title)}</span><button class="del" data-ev="${esc(e.id)}" aria-label="移除行程 ${esc(e.title)}">移除</button></li>`));
    $('dayItems').innerHTML = rows.length ? rows.join('') : '<li class="empty">這一天還沒有行程或紀念日。</li>';
    $('dayItems').querySelectorAll('[data-ev]').forEach(b => b.onclick = () => op({ op: 'removeEvent', id: b.dataset.ev }));
    $('dayItems').querySelectorAll('[data-an]').forEach(b => b.onclick = () => op({ op: 'removeAnniv', id: b.dataset.an }));
  }
  function renderUpcoming() {
    const T0 = ymdOf(nowLocal()), j0 = jdOf(T0.y, T0.m, T0.d), out = [];
    for (let k = 0; k <= 60; k++) {
      const c = ymdOf(j0 + k + .5), key = keyOf(c), hol = holidayOn(c), blk = blockOn(c);
      if (blk && (blk.idx === 1 || k === 0)) out.push({ k, c, cls: 'lj', text: `${blk.name} ${blk.len} 天（${blk.start.m}/${blk.start.d}–${blk.end.m}/${blk.end.d}）` });
      if (hol && hol.off && hol.short !== '補假' && hol.short !== '彈性放假') out.push({ k, c, cls: 'hol', text: hol.name });
      if (hol && !hol.off) out.push({ k, c, cls: 'wk', text: `${hol.name}（這天要上班）` });
      annivsOn(c).forEach(a => { const n = annivYears(a, annivDate(a, c.y)); out.push({ k, c, cls: 'an', text: `${a.name}${n > 0 ? `（第 ${n} 週年）` : ''}` }); });
      eventsOn(key).forEach(e => out.push({ k, c, cls: 'ev', text: `${e.time ? e.time + ' ' : ''}${e.title}` }));
    }
    const when = k => k === 0 ? '今天' : k === 1 ? '明天' : k === 2 ? '後天' : `${k} 天後`;
    $('upList').innerHTML = out.length ? out.slice(0, 12).map((o, i) => `<li><button class="up ${o.cls}" data-i="${i}"><span class="w">${when(o.k)}</span><span class="t">${esc(o.text)}</span><span class="d">${o.c.m}/${o.c.d}</span></button></li>`).join('') : '<li class="empty">未來 60 天沒有安排。</li>';
    $('upList').querySelectorAll('button').forEach(b => b.onclick = () => { const o = out[+b.dataset.i]; selectDate(o.c.y, o.c.m, o.c.d); });
  }

  /* ── 每日學習：內容由 api/learn.php 依日期挑選 ── */
  let tab = 'en', offset = 0, lastKey = '', learnReq = 0, current = null;
  async function renderLearn() {
    const c = SEL(), k = keyOf(c);
    if (k !== lastKey) { lastKey = k; offset = 0; }
    const req = ++learnReq;
    try {
      const d = await api(`learn.php?date=${c.y}-${pad(c.m)}-${pad(c.d)}&tab=${tab}&offset=${offset}`);
      if (req !== learnReq) return;                      // 只顯示最後一次要求的結果
      current = d; drawLearn();
    } catch (e) { $('learnBox').innerHTML = `<p class="wx-msg">無法讀取學習內容：${esc(e.message)}</p>`; }
  }
  function drawLearn() {
    if (!current) return;
    const it = current.item, box = $('learnBox');
    if (tab === 'en') box.innerHTML = `<p class="word">${esc(it.w)} <span class="pos">${esc(it.p)}</span> <span class="ipa">${esc(it.ipa)}</span></p><p class="zh">${esc(it.zh)}</p><p class="ex">${esc(it.ex)}</p><p class="exz">${esc(it.exz)}</p>`;
    else { box.innerHTML = `<p class="ctitle"><span class="lang">${esc(it.lang)}</span>${esc(it.title)}</p><pre><code></code></pre><p class="zh">${esc(it.note)}</p>`; box.querySelector('code').textContent = it.code; }
    const done = !!state.learned[current.id];
    $('lDone').textContent = done ? '✓ 已學會' : '標記為已學會'; $('lDone').setAttribute('aria-pressed', done);
    const n = Object.keys(state.learned).filter(x => x.startsWith(tab + ':')).length;
    $('learnStat').textContent = `${tab === 'en' ? '英文單字' : '程式碼'}已學會 ${n} / ${current.total} 則`;
  }
  function bindLearn() {
    document.querySelectorAll('.tabs [data-tab]').forEach(b => b.onclick = () => {
      tab = b.dataset.tab; offset = 0;
      document.querySelectorAll('.tabs [data-tab]').forEach(x => x.setAttribute('aria-selected', x === b));
      renderLearn();
    });
    $('lPrev').onclick = () => { offset--; renderLearn(); };
    $('lNext').onclick = () => { offset++; renderLearn(); };
    $('lDone').onclick = () => { if (current) op({ op: 'toggleLearned', id: current.id }); };
  }
  function bindForms() {
    $('evForm').addEventListener('submit', e => {
      e.preventDefault(); const t = $('evTitle').value.trim(); if (!t) return;
      const c = SEL(); op({ op: 'addEvent', date: keyOf(c), time: $('evTime').value, title: t });
      $('evTitle').value = ''; $('evTime').value = '';
    });
    $('anForm').addEventListener('submit', e => {
      e.preventDefault(); const t = $('anName').value.trim(); if (!t) return;
      const c = SEL(), type = $('anType').value;
      if (type === 'lunar') { const l = Solar.fromYmd(c.y, c.m, c.d).getLunar(); op({ op: 'addAnniv', name: t, type, m: Math.abs(l.getMonth()), d: l.getDay(), y0: l.getYear() }); }
      else op({ op: 'addAnniv', name: t, type, m: c.m, d: c.d, y0: c.y });
      $('anName').value = '';
    });
  }

  /* ── 鄉鎮天氣：由 api/weather.php 代為查詢並快取 ── */
  const COUNTIES = [['臺北市', 25.0375, 121.5637], ['新北市', 25.012, 121.465], ['桃園市', 24.9937, 121.301], ['臺中市', 24.1618, 120.6469], ['臺南市', 22.992, 120.185],
    ['高雄市', 22.6205, 120.312], ['基隆市', 25.131, 121.744], ['新竹市', 24.8066, 120.9686], ['新竹縣', 24.827, 121.0128], ['苗栗縣', 24.5602, 120.8214], ['彰化縣', 24.0752, 120.544],
    ['南投縣', 23.9025, 120.69], ['雲林縣', 23.7092, 120.5434], ['嘉義市', 23.4801, 120.4491], ['嘉義縣', 23.459, 120.333], ['屏東縣', 22.6727, 120.488], ['宜蘭縣', 24.73, 121.763],
    ['花蓮縣', 23.991, 121.611], ['臺東縣', 22.756, 121.144], ['澎湖縣', 23.565, 119.579], ['金門縣', 24.437, 118.319], ['連江縣', 26.16, 119.95]];
  const WMO = { 0: ['晴', '☀️'], 1: ['大致晴朗', '🌤️'], 2: ['局部多雲', '⛅'], 3: ['陰', '☁️'], 45: ['霧', '🌫️'], 48: ['霧凇', '🌫️'], 51: ['毛毛雨', '🌦️'], 53: ['毛毛雨', '🌦️'], 55: ['較密的毛毛雨', '🌧️'],
    56: ['凍毛毛雨', '🌧️'], 57: ['凍毛毛雨', '🌧️'], 61: ['小雨', '🌦️'], 63: ['中雨', '🌧️'], 65: ['大雨', '🌧️'], 66: ['凍雨', '🌧️'], 67: ['凍雨', '🌧️'], 71: ['小雪', '🌨️'], 73: ['中雪', '🌨️'],
    75: ['大雪', '❄️'], 77: ['雪粒', '🌨️'], 80: ['短暫陣雨', '🌦️'], 81: ['陣雨', '🌧️'], 82: ['強陣雨', '⛈️'], 85: ['陣雪', '🌨️'], 86: ['強陣雪', '❄️'], 95: ['雷雨', '⛈️'], 96: ['雷雨伴隨冰雹', '⛈️'], 99: ['強雷雨伴隨冰雹', '⛈️'] };
  const wmo = c => WMO[c] || ['—', '🌡️'];
  const wxMsg = html => { $('wxBox').innerHTML = `<p class="wx-msg">${html}</p>`; };
  async function loadWeather() {
    const L = state.wx || { name: '臺北市', lat: 25.0375, lon: 121.5637 };
    $('wxPlace').textContent = L.name; wxMsg('正在讀取天氣…');
    try {
      const r = await api(`weather.php?lat=${L.lat}&lon=${L.lon}`), d = r.data, cur = d.current, [txt, ico] = wmo(cur.weather_code), sel = SEL();
      const days = d.daily.time.map((t, i) => {
        const [y, m, dd] = t.split('-').map(Number), isSel = y === sel.y && m === sel.m && dd === sel.d, [tx, ic] = wmo(d.daily.weather_code[i]);
        return `<li class="${isSel ? 'sel' : ''}"><span class="dd">${i === 0 ? '今天' : `${m}/${dd}（${WEEK[Solar.fromYmd(y, m, dd).getWeek()]}）`}</span><span class="ic" title="${tx}">${ic}</span><span class="tx">${tx}</span><span class="tp">${Math.round(d.daily.temperature_2m_min[i])}–${Math.round(d.daily.temperature_2m_max[i])}°</span><span class="pp">💧${d.daily.precipitation_probability_max[i] ?? '—'}%</span></li>`;
      }).join('');
      $('wxBox').innerHTML = `<div class="wx-now"><span class="big">${ico}</span><div><p class="t">${Math.round(cur.temperature_2m)}°C <small>${txt}</small></p>
        <p class="muted">體感 ${Math.round(cur.apparent_temperature)}°　濕度 ${cur.relative_humidity_2m}%　風速 ${Math.round(cur.wind_speed_10m)} km/h</p></div></div><ul class="wx-days">${days}</ul>
        <p class="note">${r.cached ? `快取資料，更新於 ${esc(r.fetched_at)}` : `剛剛更新（${esc(r.fetched_at)}）`}${r.stale ? '，目前無法連線氣象服務，顯示的是舊資料' : ''}</p>`;
    } catch (e) { wxMsg(`無法取得天氣：${esc(e.message)}`); }
  }
  async function searchPlace() {
    const q = $('wxQ').value.trim(); if (!q) return;
    const ul = $('wxResults'); ul.innerHTML = '<li class="empty">搜尋中…</li>';
    try {
      const res = (await api(`weather.php?q=${encodeURIComponent(q)}`)).results;
      if (!res.length) { ul.innerHTML = '<li class="empty">找不到這個地名，試試加上「區」「鄉」「鎮」，或從縣市選單選擇。</li>'; return; }
      ul.innerHTML = res.map((p, i) => `<li><button data-i="${i}">${esc(p.name)}<small>${esc([p.admin2, p.admin1].filter(Boolean).join('，'))}</small></button></li>`).join('');
      ul.querySelectorAll('button').forEach(b => b.onclick = () => { const p = res[+b.dataset.i]; setPlace(`${p.name}${p.admin1 && p.admin1 !== p.name ? '，' + p.admin1 : ''}`, p.latitude, p.longitude); ul.innerHTML = ''; });
    } catch (e) { ul.innerHTML = `<li class="empty">搜尋失敗：${esc(e.message)}</li>`; }
  }
  async function setPlace(name, lat, lon) { await op({ op: 'setWeather', name, lat: +lat, lon: +lon }); loadWeather(); }
  function bindWeather() {
    const s = $('wxCounty');
    s.innerHTML = '<option value="">或選擇縣市</option>' + COUNTIES.map((c, i) => `<option value="${i}">${c[0]}</option>`).join('');
    s.onchange = () => { if (s.value === '') return; const c = COUNTIES[+s.value]; setPlace(c[0], c[1], c[2]); s.value = ''; };
    $('wxGo').onclick = searchPlace;
    $('wxQ').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchPlace(); } });
    $('wxHere').onclick = () => {
      if (!navigator.geolocation) { wxMsg('這個瀏覽器不支援定位。'); return; }
      wxMsg('正在取得位置…');
      navigator.geolocation.getCurrentPosition(p => setPlace('目前位置', p.coords.latitude, p.coords.longitude), () => wxMsg('無法取得位置，請改用搜尋或縣市選單。'), { timeout: 10000 });
    };
  }

  function refresh() { renderDay(); renderUpcoming(); drawLearn(); if (sel_ok()) renderGrid(nightOf(Tshow())); }
  const sel_ok = () => typeof Tcur === 'number' && Tcur > 0;
  async function init() { bindForms(); bindLearn(); bindWeather(); await loadState(); loadWeather(); }
  return { holidayOn, blockOn, isOff, eventsOn, annivsOn, renderDay, renderUpcoming, renderHolidays: () => {}, renderLearn, init, refresh };
})();
function renderPlanner() { P.renderDay(); P.renderLearn(); }


/* ── 說明銘牌 ── */
const plaque = $('plaque');
function openPlaque(title, sub, rows, text) {
  plaque.innerHTML = '';
  const close = document.createElement('button'); close.className = 'close'; close.textContent = '✕'; close.setAttribute('aria-label', '關閉說明'); close.onclick = () => plaque.hidden = true;
  const h = document.createElement('h3'); h.textContent = title; const p = document.createElement('p'); p.className = 'sub'; p.textContent = sub;
  plaque.append(close, h, p);
  if (rows.length) { const dl = document.createElement('dl'); rows.forEach(([k, v]) => { const dt = document.createElement('dt'); dt.textContent = k; const dd = document.createElement('dd'); dd.textContent = v; dl.append(dt, dd); }); plaque.appendChild(dl); }
  if (text) { const t = document.createElement('p'); t.className = 'text'; t.textContent = text; plaque.appendChild(t); }
  plaque.hidden = false;
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') plaque.hidden = true; });
const INFO = {
  mercury: '最靠近太陽的行星，總在太陽附近，只能在日落後或日出前短暫看到，東大距或西大距前後最好找。',
  venus: '全天除了太陽、月亮外最亮的天體，俗稱昏星（長庚）或晨星（啟明），用望遠鏡可看到像月亮一樣的盈虧。',
  earth: '我們所在的行星。地球表面的金色小點是目前選擇的觀測地點，它朝向太陽時是白天，背向太陽時是夜晚。',
  mars: '橘紅色的行星，約每 26 個月衝日一次，那時最亮、最大，也最適合觀測。衝日前後會出現明顯的逆行。',
  jupiter: '最大的行星，夜空中通常僅次於金星的亮。小望遠鏡就能看到四顆伽利略衛星和雲帶。',
  saturn: '用小望遠鏡就能看到土星環。環的傾斜角度每年都在變，約每 15 年會轉成側面而幾乎消失。',
  moon: '月亮繞地球一圈約 29.5 天。滿月前後月光很亮，會蓋掉暗淡的星星；新月前後最適合拍攝銀河與深空天體。',
  sun: '太陽在星座環上的位置就是節氣：太陽每走 15° 就是一個節氣。太陽所在的星座在白天，所以晚上看不到。',
};
function showBody(k) {
  const TS = Tshow(), st = snapshot(TS), nd = nightOf(TS), n = nightInfo(nd), t = ymdOf(TS), when = `${t.m}月${t.d}日 ${pad(t.h)}:${pad(t.mi)}`;
  if (k === 'earth') { openPlaque('地球', when, [['日心黃經', `${A.lonOf(st.helio.earth).toFixed(1)}°`], ['觀測地點', loc.name], ['午夜南方星座', zodiacOf(A.lonOf(st.helio.earth))[0]]], INFO.earth); return; }
  if (k === 'sun') { const z = zodiacOf(st.geo.sun.lon); openPlaque('太陽', when, [['視黃經', `${st.geo.sun.lon.toFixed(1)}°`], ['所在星座', z[0]], ['日落／日出', `${fmtHM(n.sunset)} ／ ${fmtHM(n.sunrise)}`]], INFO.sun); return; }
  if (k === 'moon') { const z = zodiacOf(st.geo.moon.lon); openPlaque('月球', when, [['月相', `${moonPhaseName(st.E)}，照明 ${Math.round((1 - Math.cos(deg(st.E))) / 2 * 100)}%`], ['所在星座', z[0]], ['距離', `${Math.round(st.geo.moon.dist).toLocaleString()} 公里`], ['今晚月出／月落', `${fmtHM(n.moonrise)} ／ ${fmtHM(n.moonset)}`]], INFO.moon); return; }
  const g = st.geo[k], q = S.planetNight(k, n, loc), z = zodiacOf(g.lon);
  openPlaque(BODY[k].name, when, [['所在星座', z[0]], ['亮度', `${q.mag.toFixed(1)} 等`], ['與地球距離', `${g.dist.toFixed(2)} AU（約 ${(g.dist * 1.496).toFixed(2)} 億公里）`], ['與太陽距離', `${g.r.toFixed(2)} AU`], ['距太陽角度', `${q.elong.toFixed(0)}°`], ['今晚升起／落下', `${fmtHM(q.rise)} ／ ${fmtHM(q.set)}`], ['運行方向', q.retro ? '逆行中（在星座間往西移動）' : '順行（在星座間往東移動）']], INFO[k]);
}
function showZodiac(z) {
  const st = snapshot(Tshow()), inside = [...A.PLANETS, 'moon', 'sun'].filter(k => zodiacOf(st.geo[k].lon) === z).map(k => BODY[k].name);
  // 星座中點位於午夜正南方的日期：地球日心黃經等於星座中點
  const mid = norm(z[2] + norm(z[3] - z[2]) / 2), y = ymdOf(Tshow()).y; let best = null;
  for (let d = 0; d < 366; d++) { const T = jdOf(y, 1, 1) + d + .5, l = A.lonOf(A.helio('earth', T - TZ)), diff = Math.abs(wrap180(l - mid)); if (!best || diff < best.diff) best = { diff, T }; }
  const bd = ymdOf(best.T);
  openPlaque(z[0], `${z[1]}，黃經 ${z[2].toFixed(1)}° 至 ${z[3].toFixed(1)}°`, [['目前在此星座', inside.length ? inside.join('、') : '無'], ['最佳觀賞時期', `${bd.m} 月 ${bd.d} 日前後，午夜時高掛南方`]],
    '星座範圍依國際天文學聯合會（IAU）的星座邊界，因此 13 個黃道星座寬度不一，太陽每年也會經過蛇夫座。');
}

/* ── 控制 ── */
$('playBtn').onclick = () => setPlaying(!playing);
$('speedSel').onchange = e => { speed = +e.target.value; };
$('viewBtn').onclick = () => { if (renderer) { userZoomed = false; resetView(); } };
$('nowBtn').onclick = () => setTime(nowLocal(), { abs: true });
const shiftMonth = k => {
  const base = Tshow(), nd = nightOf(base); let y = nd.y, m = nd.m + k;
  while (m < 1) { m += 12; y--; } while (m > 12) { m -= 12; y++; }
  if (y < YEAR_MIN || y > YEAR_MAX) { $('msg').textContent = `可查詢範圍為 ${YEAR_MIN} 至 ${YEAR_MAX} 年。`; return; }
  $('msg').textContent = '';
  const mo = base - (jdOf(nd.y, nd.m, nd.d) + .5);
  setTime(jdOf(y, m, Math.min(nd.d, dim(y, m))) + .5 + mo, { add: Math.abs(k) >= 12 ? 900 : 600 });   // 換月加 0.6 秒、換年加 0.9 秒
};
$('prevM').onclick = () => shiftMonth(-1); $('nextM').onclick = () => shiftMonth(1); $('prevY').onclick = () => shiftMonth(-12); $('nextY').onclick = () => shiftMonth(12);
$('dateInput').addEventListener('change', e => { const v = e.target.value.split('-').map(Number); if (v.length === 3 && v.every(x => x > 0)) { const TS = Tshow(), nd = nightOf(TS), mo = TS - (jdOf(nd.y, nd.m, nd.d) + .5); setTime(jdOf(v[0], v[1], v[2]) + .5 + mo, { abs: true }); } });
$('timeSlider').addEventListener('input', e => { const nd = nightOf(Tshow()); setPlaying(false); tween = null; Tcur = jdOf(nd.y, nd.m, nd.d) + .5 + (300 + +e.target.value) / 1440; });
LOCS.forEach(([n]) => { const o = document.createElement('option'); o.textContent = n; $('locSel').appendChild(o); });
const oc = document.createElement('option'); oc.textContent = '自訂經緯度'; oc.value = 'custom'; $('locSel').appendChild(oc);
function applyLoc() {
  const v = $('locSel').value;
  if (v === 'custom') { $('customLoc').hidden = false; const la = +$('latIn').value, lo = +$('lonIn').value; if (isFinite(la) && isFinite(lo) && Math.abs(la) < 89) loc = { name: `緯度 ${la}°，經度 ${lo}°`, lat: la, lon: lo }; }
  else { $('customLoc').hidden = true; const L = LOCS.find(x => x[0] === v); loc = { name: L[0], lat: L[1], lon: L[2] }; $('latIn').value = L[1]; $('lonIn').value = L[2]; }
  lastPanelNight = ''; lastSnapT = null; drawSky.lastT = null;
}
$('locSel').addEventListener('change', applyLoc); $('latIn').addEventListener('change', applyLoc); $('lonIn').addEventListener('change', applyLoc);
$('latIn').value = loc.lat; $('lonIn').value = loc.lon;
window.addEventListener('resize', resize);
$('qualitySel').value = qName;
$('qualitySel').onchange = e => applyQuality(e.target.value);

/* ── 啟動 ── */
if (renderer) { try { buildScene(); bindPointer(); $('loading').remove(); } catch (e) { console.error(e); renderer = null; $('loading').innerHTML = '<p class="err">3D 天文儀建構失敗，右側的觀星資訊仍可正常使用。</p>'; } }
else sizeDust();
// 預設為今晚 21:00；若現在已是夜間則用現在時刻
let T0 = nowLocal(); const tl = ymdOf(T0), hr = tl.h + tl.mi / 60;
if (hr >= 6 && hr < 18) T0 = jdOf(tl.y, tl.m, tl.d) + 21 / 24;
const hm = location.hash.match(/^#(\d{4})-(\d{2})-(\d{2})$/); if (hm) T0 = jdOf(+hm[1], +hm[2], +hm[3]) + 21 / 24;
Tcur = T0 - (reduced ? 0 : 90); setTime(T0, { dur: 3200 });
P.init();
requestAnimationFrame(t => { lastFrame = t; frame(t); });
P.renderUpcoming();
if (renderer && document.fonts) document.fonts.ready.then(() => { paintInto(tex.dial, zodiacPainter(false)); paintInto(tex.dialMetal, zodiacPainter(true)); const y = refs.calYear; refs.calYear = null; repaintCalendar(y); });
})();


/* 背景星空與流星
   效能做法：約七成星星只在視窗大小改變時畫一次（預先繪製），每次更新只重畫會閃爍的三成；
   沒有流星時降低更新頻率，有流星劃過時才全速更新。畫質設定會調整星星數量與更新頻率。 */
(() => {
  const cv = document.getElementById('bgSky'), ctx = cv.getContext('2d');
  const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const QB = { high: { density: 4200, fps: 30 }, mid: { density: 5200, fps: 24 }, low: { density: 7000, fps: 15 } };
  let q = (() => { try { return QB[localStorage.getItem('orrery-quality')] || QB.mid; } catch (e) { return QB.mid; } })();
  let W = 0, H = 0, dpr = 1, twinklers = [], meteors = [], nextAt = 1.5, last = performance.now(), lastDraw = 0;
  const layer = document.createElement('canvas'), lctx = layer.getContext('2d');
  function size() {
    dpr = Math.min(2, window.devicePixelRatio || 1); W = innerWidth; H = innerHeight;
    cv.width = layer.width = Math.round(W * dpr); cv.height = layer.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); lctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    lctx.clearRect(0, 0, W, H); twinklers = [];
    const n = Math.round(W * H / q.density);
    for (let i = 0; i < n; i++) {
      const big = Math.random() < .07, s = { x: Math.random() * W, y: Math.random() * H, r: big ? 1.3 + Math.random() * .8 : .3 + Math.random() * 1.1,
        a: Math.random() * 6.28, sp: .5 + Math.random() * 1.2, big, c: Math.random() < .25 ? '255,232,180' : '225,234,255' };
      if (big || Math.random() < .25) twinklers.push(s);
      else { lctx.fillStyle = `rgba(${s.c},${.25 + Math.random() * .35})`; lctx.beginPath(); lctx.arc(s.x, s.y, s.r, 0, 6.283); lctx.fill(); }
    }
    draw(0);
  }
  function spawn() {
    const ang = (200 + Math.random() * 30) * Math.PI / 180, sp = 650 + Math.random() * 600;
    meteors.push({ x: W * (.25 + Math.random() * .85), y: -20 + Math.random() * H * .45, vx: Math.cos(ang) * sp, vy: -Math.sin(ang) * sp,
      len: 110 + Math.random() * 180, life: 0, max: .7 + Math.random() * .7, w: 1 + Math.random() * 1.2, gold: Math.random() < .35 });
  }
  function draw(dt) {
    ctx.clearRect(0, 0, W, H);
    ctx.drawImage(layer, 0, 0, W, H);
    for (const s of twinklers) {
      s.a += dt * s.sp;
      const tw = Math.pow(.5 + .5 * Math.sin(s.a), 3), al = .12 + .78 * tw;
      ctx.fillStyle = `rgba(${s.c},${al})`; ctx.beginPath(); ctx.arc(s.x, s.y, s.r * (.8 + .5 * tw), 0, 6.283); ctx.fill();
      if (s.big && tw > .35) {
        const L = s.r * 7 * tw;
        ctx.fillStyle = `rgba(${s.c},${.18 * tw})`; ctx.beginPath(); ctx.arc(s.x, s.y, s.r * 4, 0, 6.283); ctx.fill();
        ctx.strokeStyle = `rgba(${s.c},${.7 * tw})`; ctx.lineWidth = .8;
        ctx.beginPath(); ctx.moveTo(s.x - L, s.y); ctx.lineTo(s.x + L, s.y); ctx.moveTo(s.x, s.y - L); ctx.lineTo(s.x, s.y + L); ctx.stroke();
      }
    }
    for (const m of meteors) {
      m.x += m.vx * dt; m.y += m.vy * dt;
      const k = m.life / m.max, fade = k < .15 ? k / .15 : 1 - (k - .15) / .85;
      const sp = Math.hypot(m.vx, m.vy), tx = m.x - m.vx / sp * m.len, ty = m.y - m.vy / sp * m.len;
      const g = ctx.createLinearGradient(m.x, m.y, tx, ty), c = m.gold ? '255,226,160' : '220,232,255';
      g.addColorStop(0, `rgba(${c},${.9 * fade})`); g.addColorStop(.3, `rgba(${c},${.35 * fade})`); g.addColorStop(1, `rgba(${c},0)`);
      ctx.strokeStyle = g; ctx.lineWidth = m.w; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(tx, ty); ctx.stroke();
      ctx.fillStyle = `rgba(255,255,255,${.8 * fade})`; ctx.beginPath(); ctx.arc(m.x, m.y, 1.6 * m.w, 0, 6.283); ctx.fill();
    }
  }
  function loop(now) {
    const dt = Math.min(.1, (now - last) / 1000); last = now;
    nextAt -= dt;
    if (nextAt <= 0) { spawn(); nextAt = 1.8 + Math.random() * 3.6; }
    meteors.forEach(m => m.life += dt); meteors = meteors.filter(m => m.life < m.max);
    const interval = meteors.length ? 0 : 1000 / q.fps;            // 有流星時全速，否則依畫質降頻
    if (now - lastDraw >= interval) { draw((now - lastDraw) / 1000 > .5 ? dt : (now - lastDraw) / 1000); lastDraw = now; }
    requestAnimationFrame(loop);
  }
  addEventListener('resize', size);
  addEventListener('orrery-quality', e => { q = QB[e.detail] || QB.mid; size(); });
  size();
  if (!still) requestAnimationFrame(t => { last = lastDraw = t; loop(t); });
})();


/* ════════════════════════════════════════════════════════════
   滑鼠移動軌跡：碎星星
   移動時灑出小星星，受重力落下、旋轉、閃爍；較大的星星在途中碎裂成更小的碎片。
   點擊時迸出一小團星星。尊重「減少動態效果」設定。
   ════════════════════════════════════════════════════════════ */
(() => {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const cv = document.createElement('canvas');
  cv.id = 'starTrail'; cv.setAttribute('aria-hidden', 'true');
  Object.assign(cv.style, { position: 'fixed', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', zIndex: '9999' });
  document.body.appendChild(cv);
  const ctx = cv.getContext('2d');
  let W = 0, H = 0, dpr = 1, parts = [], running = false, last = 0, lx = null, ly = null;
  const COLORS = ['255,222,140', '255,245,210', '255,200,120', '200,220,255', '255,180,200'];
  function size() { dpr = Math.min(2, window.devicePixelRatio || 1); W = innerWidth; H = innerHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
  function spawn(x, y, n, burst) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, sp = burst ? 80 + Math.random() * 220 : 15 + Math.random() * 60;
      parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - (burst ? 60 : 20), r: burst ? 4 + Math.random() * 6 : 3 + Math.random() * 5,
        rot: Math.random() * 6.28, vr: (Math.random() - .5) * 8, life: 0, max: .7 + Math.random() * .8, col: COLORS[Math.random() * COLORS.length | 0],
        tw: Math.random() * 6.28, shard: false });
    }
    if (parts.length > 400) parts.splice(0, parts.length - 400);
    if (!running) { running = true; last = performance.now(); requestAnimationFrame(step); }
  }
  function starPath(r, spikes = 5, inner = .45) {
    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) { const rr = i % 2 ? r * inner : r, a = i * Math.PI / spikes - Math.PI / 2; i ? ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); }
    ctx.closePath();
  }
  function step(now) {
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    ctx.clearRect(0, 0, W, H);
    ctx.globalCompositeOperation = 'lighter';
    const born = [];
    parts = parts.filter(p => {
      p.life += dt; if (p.life >= p.max) return false;
      p.vy += 240 * dt; p.vx *= .985; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt; p.tw += dt * 14;
      // 碎裂：較大的星星飛到一半時裂成 3～4 片小碎星
      if (!p.shard && p.r > 5 && p.life > p.max * .45) {
        const n = 3 + (Math.random() * 2 | 0);
        for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, sp = 40 + Math.random() * 90;
          born.push({ ...p, vx: p.vx * .4 + Math.cos(a) * sp, vy: p.vy * .4 + Math.sin(a) * sp, r: p.r * (.3 + Math.random() * .2), life: 0, max: .4 + Math.random() * .5, shard: true, vr: (Math.random() - .5) * 14 }); }
        return false;
      }
      const k = p.life / p.max, al = (1 - k) * (.65 + .35 * Math.sin(p.tw)), r = p.r * (1 - k * .4);
      ctx.save(); ctx.translate(p.x, p.y);
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, r * 2.4);
      g.addColorStop(0, `rgba(${p.col},${al * .55})`); g.addColorStop(1, `rgba(${p.col},0)`);
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r * 2.4, 0, 6.283); ctx.fill();
      ctx.rotate(p.rot); starPath(r, p.shard ? 4 : 5, p.shard ? .35 : .45);
      ctx.fillStyle = `rgba(${p.col},${al})`; ctx.fill();
      ctx.restore();
      return true;
    });
    parts.push(...born);
    ctx.globalCompositeOperation = 'source-over';
    if (parts.length) requestAnimationFrame(step); else { running = false; ctx.clearRect(0, 0, W, H); }
  }
  addEventListener('pointermove', e => {
    if (lx === null) { lx = e.clientX; ly = e.clientY; return; }
    const d = Math.hypot(e.clientX - lx, e.clientY - ly);
    if (d < 9) return;
    spawn(e.clientX, e.clientY, Math.min(3, 1 + (d / 30 | 0)), false);
    lx = e.clientX; ly = e.clientY;
  }, { passive: true });
  addEventListener('pointerdown', e => spawn(e.clientX, e.clientY, 14, true), { passive: true });
  addEventListener('resize', size); size();
})();


/* 側邊抽屜：開關、跳到指定區塊、Esc 關閉，關閉後焦點回到原本的按鈕 */
(() => {
  const dr = document.getElementById('drawer'), mask = document.getElementById('drawerMask'), tab = document.getElementById('drawerTab'), body = dr.querySelector('.drawer-body');
  let opener = null;
  function open(target, from) {
    opener = from || document.activeElement;
    dr.classList.add('open'); mask.classList.add('show'); dr.setAttribute('aria-hidden', 'false'); tab.setAttribute('aria-expanded', 'true');
    if (target) { const el = document.getElementById(target); if (el) requestAnimationFrame(() => el.scrollIntoView({ block: 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' })); }
    setTimeout(() => document.getElementById('drawerClose').focus({ preventScroll: true }), 60);
  }
  function close() {
    if (!dr.classList.contains('open')) return;
    dr.classList.remove('open'); mask.classList.remove('show'); dr.setAttribute('aria-hidden', 'true'); tab.setAttribute('aria-expanded', 'false');
    if (opener && opener.focus) opener.focus({ preventScroll: true });
  }
  tab.addEventListener('click', () => dr.classList.contains('open') ? close() : open(null, tab));
  mask.addEventListener('click', close);
  document.getElementById('drawerClose').addEventListener('click', close);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  dr.querySelectorAll('.drawer-nav [data-go]').forEach(b => b.addEventListener('click', () => {
    const el = document.getElementById(b.dataset.go); if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }));
  document.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => open(b.dataset.open, b)));
  // 捲動時標示目前所在的區塊
  const chips = [...dr.querySelectorAll('.drawer-nav [data-go]')];
  body.addEventListener('scroll', () => {
    let cur = chips[0];
    for (const c of chips) { const el = document.getElementById(c.dataset.go); if (el && el.offsetTop - body.offsetTop <= body.scrollTop + 40) cur = c; }
    chips.forEach(c => c.classList.toggle('on', c === cur));
  }, { passive: true });
})();
